import { Resend } from 'resend'
import { buildTrackedLink, buildTrackingPixelUrl } from './utils'

export const resend = new Resend(process.env.RESEND_API_KEY)

// ─── Inject tracking pixel + link wrappers into campaign HTML ─────────────────

export function injectTracking(
  html: string,
  campaignContactId: string
): string {
  // Replace all <a href="..."> links with tracked versions
  const withLinks = html.replace(
    /href="(https?:\/\/[^"]+)"/g,
    (_, url) => `href="${buildTrackedLink(campaignContactId, url)}"`
  )

  // Append 1×1 tracking pixel before </body>
  const pixel = `<img src="${buildTrackingPixelUrl(campaignContactId)}" width="1" height="1" alt="" style="display:none" />`
  return withLinks.replace('</body>', `${pixel}</body>`) || withLinks + pixel
}

// ─── Send a campaign email to one recipient ───────────────────────────────────

export async function sendCampaignEmail({
  to,
  fromName,
  fromEmail,
  subject,
  html,
  campaignContactId,
}: {
  to: string
  fromName: string
  fromEmail: string
  subject: string
  html: string
  campaignContactId: string
}) {
  const trackedHtml = injectTracking(html, campaignContactId)

  return resend.emails.send({
    from: `${fromName} <${fromEmail}>`,
    to,
    subject,
    html: trackedHtml,
  })
}
