import { headers } from 'next/headers'
import { NextResponse } from 'next/server'
import { Webhook } from 'svix'
import { prisma } from '@/lib/prisma'

// Clerk sends a webhook on user.created / user.updated / user.deleted.
// Set CLERK_WEBHOOK_SECRET in your env from the Clerk dashboard.
const WEBHOOK_SECRET = process.env.CLERK_WEBHOOK_SECRET

// POST /api/webhooks/clerk
export async function POST(req: Request) {
  if (!WEBHOOK_SECRET) {
    console.warn('CLERK_WEBHOOK_SECRET not set — skipping webhook verification')
  }

  const payload = await req.text()
  const headerPayload = headers()

  const svixId        = headerPayload.get('svix-id') ?? ''
  const svixTimestamp = headerPayload.get('svix-timestamp') ?? ''
  const svixSignature = headerPayload.get('svix-signature') ?? ''

  // Verify signature when secret is set
  if (WEBHOOK_SECRET) {
    try {
      const wh = new Webhook(WEBHOOK_SECRET)
      wh.verify(payload, {
        'svix-id':        svixId,
        'svix-timestamp': svixTimestamp,
        'svix-signature': svixSignature,
      })
    } catch {
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
    }
  }

  const event = JSON.parse(payload)
  const { type, data } = event

  switch (type) {
    case 'user.created': {
      const primaryEmail = data.email_addresses?.find(
        (e: any) => e.id === data.primary_email_address_id
      )?.email_address

      await prisma.user.upsert({
        where: { clerkId: data.id },
        create: {
          clerkId:   data.id,
          email:     primaryEmail ?? `${data.id}@unknown.com`,
          name:      [data.first_name, data.last_name].filter(Boolean).join(' ') || null,
          avatarUrl: data.image_url ?? null,
        },
        update: {},
      })
      break
    }

    case 'user.updated': {
      const primaryEmail = data.email_addresses?.find(
        (e: any) => e.id === data.primary_email_address_id
      )?.email_address

      await prisma.user.updateMany({
        where: { clerkId: data.id },
        data: {
          name:      [data.first_name, data.last_name].filter(Boolean).join(' ') || null,
          avatarUrl: data.image_url ?? null,
          ...(primaryEmail && { email: primaryEmail }),
        },
      })
      break
    }

    case 'user.deleted': {
      await prisma.user.deleteMany({ where: { clerkId: data.id } })
      break
    }
  }

  return NextResponse.json({ received: true })
}
