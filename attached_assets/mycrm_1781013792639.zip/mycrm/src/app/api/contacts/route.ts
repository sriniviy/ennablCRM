import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/contacts
export async function GET(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const q        = searchParams.get('q') ?? ''
  const status   = searchParams.get('status') ?? ''
  const page     = Number(searchParams.get('page') ?? 1)
  const pageSize = Number(searchParams.get('pageSize') ?? 25)

  const where = {
    ...(q && {
      OR: [
        { firstName: { contains: q, mode: 'insensitive' as const } },
        { lastName:  { contains: q, mode: 'insensitive' as const } },
        { email:     { contains: q, mode: 'insensitive' as const } },
      ],
    }),
    ...(status && { status: status as any }),
  }

  const [data, total] = await Promise.all([
    prisma.contact.findMany({
      where,
      skip: (page - 1) * pageSize,
      take: pageSize,
      orderBy: { createdAt: 'desc' },
      include: {
        company:  { select: { id: true, name: true } },
        assignee: { select: { id: true, name: true } },
        _count: { select: { deals: true, tasks: true } },
      },
    }),
    prisma.contact.count({ where }),
  ])

  return NextResponse.json({ data, total, page, pageSize })
}

// POST /api/contacts
export async function POST(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { firstName, lastName, email, phone, title, status, companyId, tags, notes, linkedIn } = body

  if (!firstName || !lastName) {
    return NextResponse.json({ error: 'First name and last name are required' }, { status: 400 })
  }

  // Find the user record for activity log
  const user = await prisma.user.findUnique({ where: { clerkId: userId } })

  const contact = await prisma.contact.create({
    data: {
      firstName,
      lastName,
      email: email || undefined,
      phone: phone || undefined,
      title: title || undefined,
      status: status ?? 'LEAD',
      companyId: companyId || undefined,
      tags: tags ?? [],
      notes: notes || undefined,
      linkedIn: linkedIn || undefined,
      assigneeId: user?.id ?? undefined,
      activities: {
        create: {
          type: 'CONTACT_CREATED',
          title: `${firstName} ${lastName} was added`,
          userId: user?.id,
        },
      },
    },
    include: {
      company: { select: { id: true, name: true } },
    },
  })

  return NextResponse.json({ data: contact }, { status: 201 })
}
