import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

interface ImportRow {
  firstName: string
  lastName:  string
  email?:    string
  phone?:    string
  title?:    string
  tags?:     string[]
  notes?:    string
}

// POST /api/contacts/import
export async function POST(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { contacts }: { contacts: ImportRow[] } = await req.json()

  if (!Array.isArray(contacts) || contacts.length === 0) {
    return NextResponse.json({ error: 'No contacts provided' }, { status: 400 })
  }

  if (contacts.length > 1000) {
    return NextResponse.json({ error: 'Max 1,000 contacts per import' }, { status: 400 })
  }

  const user = await prisma.user.findUnique({ where: { clerkId: userId } })

  let imported = 0
  let skipped  = 0

  // Process in batches of 50 to avoid overwhelming the DB
  const batchSize = 50
  for (let i = 0; i < contacts.length; i += batchSize) {
    const batch = contacts.slice(i, i + batchSize)

    for (const row of batch) {
      if (!row.firstName?.trim() || !row.lastName?.trim()) {
        skipped++
        continue
      }

      // Skip if email already exists
      if (row.email?.trim()) {
        const existing = await prisma.contact.findUnique({
          where: { email: row.email.trim() },
          select: { id: true },
        })
        if (existing) { skipped++; continue }
      }

      try {
        await prisma.contact.create({
          data: {
            firstName:  row.firstName.trim(),
            lastName:   row.lastName.trim(),
            email:      row.email?.trim()  || undefined,
            phone:      row.phone?.trim()  || undefined,
            title:      row.title?.trim()  || undefined,
            tags:       row.tags           ?? [],
            notes:      row.notes?.trim()  || undefined,
            assigneeId: user?.id,
            activities: {
              create: {
                type:   'CONTACT_CREATED',
                title:  `${row.firstName} ${row.lastName} imported from CSV`,
                userId: user?.id,
              },
            },
          },
        })
        imported++
      } catch {
        // e.g. unique constraint on email from a race condition
        skipped++
      }
    }
  }

  return NextResponse.json({ imported, skipped })
}
