import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

interface Params { params: { id: string } }

// GET /api/contacts/[id]
export async function GET(_: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const contact = await prisma.contact.findUnique({
    where: { id: params.id },
    include: {
      company:   true,
      assignee:  { select: { id: true, name: true, avatarUrl: true } },
      deals:     { include: { stage: true } },
      tasks:     { where: { completed: false }, orderBy: { dueDate: 'asc' } },
      activities:{ orderBy: { createdAt: 'desc' }, take: 30, include: { user: { select: { name: true } } } },
    },
  })

  if (!contact) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({ data: contact })
}

// PATCH /api/contacts/[id]
export async function PATCH(req: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()

  const contact = await prisma.contact.update({
    where: { id: params.id },
    data: {
      ...(body.firstName   !== undefined && { firstName:   body.firstName }),
      ...(body.lastName    !== undefined && { lastName:    body.lastName }),
      ...(body.email       !== undefined && { email:       body.email || null }),
      ...(body.phone       !== undefined && { phone:       body.phone || null }),
      ...(body.title       !== undefined && { title:       body.title || null }),
      ...(body.status      !== undefined && { status:      body.status }),
      ...(body.companyId   !== undefined && { companyId:   body.companyId || null }),
      ...(body.assigneeId  !== undefined && { assigneeId:  body.assigneeId || null }),
      ...(body.tags        !== undefined && { tags:        body.tags }),
      ...(body.notes       !== undefined && { notes:       body.notes || null }),
      ...(body.linkedIn    !== undefined && { linkedIn:    body.linkedIn || null }),
    },
  })

  return NextResponse.json({ data: contact })
}

// DELETE /api/contacts/[id]
export async function DELETE(_: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  await prisma.contact.delete({ where: { id: params.id } })
  return NextResponse.json({ message: 'Contact deleted' })
}
