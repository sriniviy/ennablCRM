import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'

// GET /api/track/click/[id]?url=<destination>
export async function GET(req: Request, { params }: { params: { id: string } }) {
  const { searchParams } = new URL(req.url)
  const destination = searchParams.get('url') ?? '/'

  try {
    await prisma.campaignContact.updateMany({
      where: { id: params.id, clickedAt: null },
      data:  { status: 'CLICKED', clickedAt: new Date() },
    })

    const cc = await prisma.campaignContact.findUnique({
      where: { id: params.id },
      select: { contactId: true },
    })
    if (cc) {
      await prisma.activity.create({
        data: {
          type:      'EMAIL_CLICKED',
          title:     'Email link clicked',
          contactId: cc.contactId,
          metadata:  { campaignContactId: params.id, url: destination },
        },
      })
    }
  } catch {
    // Silently fail
  }

  redirect(destination)
}
