import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// 1×1 transparent GIF bytes
const PIXEL = Buffer.from(
  'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
  'base64'
)

// GET /api/track/open/[id]
export async function GET(_: Request, { params }: { params: { id: string } }) {
  try {
    // Record the open (only on first open)
    await prisma.campaignContact.updateMany({
      where: { id: params.id, openedAt: null },
      data:  { status: 'OPENED', openedAt: new Date() },
    })

    // Log activity
    const cc = await prisma.campaignContact.findUnique({
      where: { id: params.id },
      select: { contactId: true, campaignId: true },
    })
    if (cc) {
      await prisma.activity.create({
        data: {
          type:      'EMAIL_OPENED',
          title:     'Email opened',
          contactId: cc.contactId,
          metadata:  { campaignContactId: params.id },
        },
      })
    }
  } catch {
    // Silently fail — tracking should never break email delivery
  }

  return new NextResponse(PIXEL, {
    status: 200,
    headers: {
      'Content-Type':  'image/gif',
      'Cache-Control': 'no-store, no-cache, must-revalidate',
      'Pragma':        'no-cache',
    },
  })
}
