import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/activities?contactId=xxx&dealId=xxx
export async function GET(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const contactId = searchParams.get('contactId')
  const dealId    = searchParams.get('dealId')
  const limit     = Number(searchParams.get('limit') ?? 30)

  const activities = await prisma.activity.findMany({
    where: {
      ...(contactId && { contactId }),
      ...(dealId    && { dealId }),
    },
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: {
      user:    { select: { id: true, name: true, avatarUrl: true } },
      contact: { select: { id: true, firstName: true, lastName: true } },
      deal:    { select: { id: true, title: true } },
    },
  })

  return NextResponse.json({ data: activities })
}

// POST /api/activities  — manually log a note, call, or meeting
export async function POST(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { type, title, description, contactId, dealId, companyId } = body

  if (!type || !title) {
    return NextResponse.json({ error: 'Type and title are required' }, { status: 400 })
  }

  const ALLOWED_MANUAL = ['NOTE', 'CALL', 'EMAIL_SENT', 'MEETING', 'FOLLOW_UP']
  if (!ALLOWED_MANUAL.includes(type)) {
    return NextResponse.json({ error: 'Invalid activity type' }, { status: 400 })
  }

  const user = await prisma.user.findUnique({ where: { clerkId: userId } })

  const activity = await prisma.activity.create({
    data: {
      type,
      title:       title.trim(),
      description: description?.trim() || undefined,
      userId:      user?.id,
      contactId:   contactId  || undefined,
      dealId:      dealId     || undefined,
      companyId:   companyId  || undefined,
    },
    include: {
      user: { select: { id: true, name: true, avatarUrl: true } },
    },
  })

  return NextResponse.json({ data: activity }, { status: 201 })
}
