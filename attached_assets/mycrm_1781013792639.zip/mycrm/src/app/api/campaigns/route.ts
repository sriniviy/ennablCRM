import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { sendCampaignEmail } from '@/lib/resend'

// GET /api/campaigns
export async function GET() {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const campaigns = await prisma.emailCampaign.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      _count: { select: { recipients: true } },
    },
  })

  return NextResponse.json({ data: campaigns })
}

// POST /api/campaigns  — create a campaign
export async function POST(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { name, subject, fromName, fromEmail, htmlContent, textContent, contactIds } = body

  if (!name || !subject || !fromName || !fromEmail || !htmlContent) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
  }

  // Fetch target contacts
  const contacts = contactIds?.length
    ? await prisma.contact.findMany({
        where: { id: { in: contactIds }, email: { not: null } },
        select: { id: true, email: true },
      })
    : []

  const campaign = await prisma.emailCampaign.create({
    data: {
      name,
      subject,
      fromName,
      fromEmail,
      htmlContent,
      textContent: textContent || undefined,
      recipients: {
        createMany: {
          data: contacts.map((c) => ({
            contactId: c.id,
            email:     c.email!,
          })),
        },
      },
    },
    include: { _count: { select: { recipients: true } } },
  })

  return NextResponse.json({ data: campaign }, { status: 201 })
}

// PATCH /api/campaigns  — send a campaign
export async function PATCH(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id, action } = await req.json()
  if (action !== 'send') return NextResponse.json({ error: 'Unknown action' }, { status: 400 })

  const campaign = await prisma.emailCampaign.findUnique({
    where: { id },
    include: { recipients: { where: { status: 'PENDING' } } },
  })
  if (!campaign) return NextResponse.json({ error: 'Campaign not found' }, { status: 404 })
  if (campaign.status !== 'DRAFT') {
    return NextResponse.json({ error: 'Campaign is not in draft status' }, { status: 400 })
  }

  // Mark as sending
  await prisma.emailCampaign.update({
    where: { id },
    data: { status: 'SENDING' },
  })

  // Send each email (in production, use a queue like BullMQ or Trigger.dev)
  const results = await Promise.allSettled(
    campaign.recipients.map(async (r) => {
      const { error } = await sendCampaignEmail({
        to:               r.email,
        fromName:         campaign.fromName,
        fromEmail:        campaign.fromEmail,
        subject:          campaign.subject,
        html:             campaign.htmlContent,
        campaignContactId: r.id,
      })

      if (error) throw new Error(error.message)

      await prisma.campaignContact.update({
        where: { id: r.id },
        data: { status: 'SENT', sentAt: new Date() },
      })
    })
  )

  const sent   = results.filter((r) => r.status === 'fulfilled').length
  const failed = results.filter((r) => r.status === 'rejected').length

  // Mark campaign as sent
  await prisma.emailCampaign.update({
    where: { id },
    data: { status: 'SENT', sentAt: new Date() },
  })

  return NextResponse.json({ data: { sent, failed } })
}
