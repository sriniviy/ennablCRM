import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/tasks
export async function GET(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const filter = searchParams.get('filter') ?? 'open'

  const where =
    filter === 'completed'
      ? { completed: true }
      : filter === 'overdue'
        ? { completed: false, dueDate: { lt: new Date() } }
        : { completed: false }

  const tasks = await prisma.task.findMany({
    where,
    orderBy: [{ dueDate: 'asc' }, { priority: 'asc' }],
    include: {
      contact:  { select: { id: true, firstName: true, lastName: true } },
      deal:     { select: { id: true, title: true } },
      assignee: { select: { id: true, name: true } },
    },
  })

  return NextResponse.json({ data: tasks })
}

// POST /api/tasks
export async function POST(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { title, description, dueDate, priority, type, contactId, dealId, assigneeId } = body

  if (!title) return NextResponse.json({ error: 'Title is required' }, { status: 400 })

  const user = await prisma.user.findUnique({ where: { clerkId: userId } })

  const task = await prisma.task.create({
    data: {
      title,
      description: description || undefined,
      dueDate:     dueDate ? new Date(dueDate) : undefined,
      priority:    priority ?? 'MEDIUM',
      type:        type ?? 'TODO',
      contactId:   contactId || undefined,
      dealId:      dealId || undefined,
      assigneeId:  assigneeId || user?.id,
      creatorId:   user?.id,
      activities: {
        create: {
          type:  'TASK_CREATED',
          title: `Task "${title}" created`,
          userId: user?.id,
          contactId: contactId || undefined,
          dealId: dealId || undefined,
        },
      },
    },
  })

  return NextResponse.json({ data: task }, { status: 201 })
}

// PATCH /api/tasks (bulk update — not used yet, placeholder)
export async function PATCH(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id, ...data } = await req.json()
  if (!id) return NextResponse.json({ error: 'Task ID required' }, { status: 400 })

  const user = await prisma.user.findUnique({ where: { clerkId: userId } })
  const existing = await prisma.task.findUnique({ where: { id } })
  if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const completing = data.completed === true && !existing.completed

  const task = await prisma.task.update({
    where: { id },
    data: {
      ...(data.completed !== undefined && {
        completed:   data.completed,
        completedAt: data.completed ? new Date() : null,
      }),
      ...(data.title       !== undefined && { title:       data.title }),
      ...(data.dueDate     !== undefined && { dueDate:     data.dueDate ? new Date(data.dueDate) : null }),
      ...(data.priority    !== undefined && { priority:    data.priority }),
      ...(data.assigneeId  !== undefined && { assigneeId:  data.assigneeId || null }),
      ...(completing && {
        activities: {
          create: {
            type:  'TASK_COMPLETED',
            title: `Task "${existing.title}" completed`,
            userId: user?.id,
          },
        },
      }),
    },
  })

  return NextResponse.json({ data: task })
}
