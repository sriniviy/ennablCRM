import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

interface Params { params: { id: string } }

export async function PATCH(req: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const data = await req.json()
  const user = await prisma.user.findUnique({ where: { clerkId: userId } })
  const existing = await prisma.task.findUnique({ where: { id: params.id } })
  if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const completing = data.completed === true && !existing.completed

  const task = await prisma.task.update({
    where: { id: params.id },
    data: {
      ...(data.completed !== undefined && {
        completed:   data.completed,
        completedAt: data.completed ? new Date() : null,
      }),
      ...(data.title      !== undefined && { title:      data.title }),
      ...(data.dueDate    !== undefined && { dueDate:    data.dueDate ? new Date(data.dueDate) : null }),
      ...(data.priority   !== undefined && { priority:   data.priority }),
      ...(data.assigneeId !== undefined && { assigneeId: data.assigneeId || null }),
      ...(completing && {
        activities: {
          create: {
            type:   'TASK_COMPLETED',
            title:  `Task "${existing.title}" completed`,
            userId: user?.id,
          },
        },
      }),
    },
  })

  return NextResponse.json({ data: task })
}

export async function DELETE(_: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  await prisma.task.delete({ where: { id: params.id } })
  return NextResponse.json({ message: 'Task deleted' })
}
