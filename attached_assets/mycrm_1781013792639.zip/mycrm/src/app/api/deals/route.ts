import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/deals
export async function GET(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const stageId = searchParams.get('stageId')

  const deals = await prisma.deal.findMany({
    where: stageId ? { stageId } : undefined,
    orderBy: [{ stageId: 'asc' }, { order: 'asc' }],
    include: {
      stage:    true,
      contact:  { select: { id: true, firstName: true, lastName: true, email: true } },
      company:  { select: { id: true, name: true } },
      assignee: { select: { id: true, name: true } },
    },
  })

  return NextResponse.json({ data: deals })
}

// POST /api/deals
export async function POST(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { title, value, stageId, contactId, companyId, closeDate, probability, notes } = body

  if (!title || !stageId) {
    return NextResponse.json({ error: 'Title and stage are required' }, { status: 400 })
  }

  const user = await prisma.user.findUnique({ where: { clerkId: userId } })
  const stage = await prisma.dealStage.findUnique({ where: { id: stageId } })

  const deal = await prisma.deal.create({
    data: {
      title,
      value:       value ? Number(value) : undefined,
      stageId,
      contactId:   contactId || undefined,
      companyId:   companyId || undefined,
      assigneeId:  user?.id,
      closeDate:   closeDate ? new Date(closeDate) : undefined,
      probability: probability ? Number(probability) : 50,
      notes:       notes || undefined,
      activities: {
        create: {
          type:    'DEAL_CREATED',
          title:   `Deal "${title}" created`,
          userId:  user?.id,
          contactId: contactId || undefined,
        },
      },
    },
    include: { stage: true },
  })

  return NextResponse.json({ data: deal }, { status: 201 })
}
