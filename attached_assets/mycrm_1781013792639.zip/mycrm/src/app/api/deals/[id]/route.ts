import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

interface Params { params: { id: string } }

// PATCH /api/deals/[id]  — handles stage moves, value updates, etc.
export async function PATCH(req: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const user  = await prisma.user.findUnique({ where: { clerkId: userId } })
  const existing = await prisma.deal.findUnique({
    where: { id: params.id },
    include: { stage: true },
  })
  if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  // Detect stage move for activity log
  const stageChanged = body.stageId && body.stageId !== existing.stageId
  let newStage = existing.stage
  if (stageChanged) {
    newStage = await prisma.dealStage.findUnique({ where: { id: body.stageId } }) ?? existing.stage
  }

  // Build activity type
  let activityType: 'DEAL_MOVED' | 'DEAL_WON' | 'DEAL_LOST' = 'DEAL_MOVED'
  if (stageChanged && newStage.name === 'Won')  activityType = 'DEAL_WON'
  if (stageChanged && newStage.name === 'Lost') activityType = 'DEAL_LOST'

  const deal = await prisma.deal.update({
    where: { id: params.id },
    data: {
      ...(body.title      !== undefined && { title:       body.title }),
      ...(body.value      !== undefined && { value:       body.value ? Number(body.value) : null }),
      ...(body.stageId    !== undefined && { stageId:     body.stageId }),
      ...(body.order      !== undefined && { order:       body.order }),
      ...(body.probability!== undefined && { probability: body.probability }),
      ...(body.closeDate  !== undefined && { closeDate:   body.closeDate ? new Date(body.closeDate) : null }),
      ...(body.contactId  !== undefined && { contactId:   body.contactId || null }),
      ...(body.companyId  !== undefined && { companyId:   body.companyId || null }),
      ...(body.notes      !== undefined && { notes:       body.notes || null }),
      ...(stageChanged && {
        activities: {
          create: {
            type:    activityType,
            title:   `Deal moved to "${newStage.name}"`,
            description: `From "${existing.stage.name}" → "${newStage.name}"`,
            userId:  user?.id,
          },
        },
      }),
    },
    include: { stage: true },
  })

  return NextResponse.json({ data: deal })
}

// DELETE /api/deals/[id]
export async function DELETE(_: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  await prisma.deal.delete({ where: { id: params.id } })
  return NextResponse.json({ message: 'Deal deleted' })
}
