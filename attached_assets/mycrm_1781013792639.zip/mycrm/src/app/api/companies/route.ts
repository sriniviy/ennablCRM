import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const q = searchParams.get('q') ?? ''

  const companies = await prisma.company.findMany({
    where: q ? { name: { contains: q, mode: 'insensitive' } } : undefined,
    orderBy: { name: 'asc' },
    include: { _count: { select: { contacts: true, deals: true } } },
  })

  return NextResponse.json({ data: companies })
}

export async function POST(req: Request) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { name, domain, industry, size, website, phone, address, city, country } = body

  if (!name) return NextResponse.json({ error: 'Name is required' }, { status: 400 })

  const company = await prisma.company.create({
    data: {
      name,
      domain:   domain   || undefined,
      industry: industry || undefined,
      size:     size     || undefined,
      website:  website  || undefined,
      phone:    phone    || undefined,
      address:  address  || undefined,
      city:     city     || undefined,
      country:  country  || undefined,
    },
  })

  return NextResponse.json({ data: company }, { status: 201 })
}
