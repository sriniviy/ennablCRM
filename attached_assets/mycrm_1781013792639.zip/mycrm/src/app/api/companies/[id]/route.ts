import { auth } from '@clerk/nextjs/server'
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

interface Params { params: { id: string } }

export async function GET(_: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const company = await prisma.company.findUnique({
    where: { id: params.id },
    include: {
      contacts: { select: { id: true, firstName: true, lastName: true, status: true, title: true } },
      deals:    { include: { stage: true } },
    },
  })

  if (!company) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({ data: company })
}

export async function PATCH(req: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()

  const company = await prisma.company.update({
    where: { id: params.id },
    data: {
      ...(body.name     !== undefined && { name:     body.name }),
      ...(body.domain   !== undefined && { domain:   body.domain   || null }),
      ...(body.industry !== undefined && { industry: body.industry || null }),
      ...(body.size     !== undefined && { size:     body.size     || null }),
      ...(body.website  !== undefined && { website:  body.website  || null }),
      ...(body.phone    !== undefined && { phone:    body.phone    || null }),
      ...(body.address  !== undefined && { address:  body.address  || null }),
      ...(body.city     !== undefined && { city:     body.city     || null }),
      ...(body.country  !== undefined && { country:  body.country  || null }),
    },
  })

  return NextResponse.json({ data: company })
}

export async function DELETE(_: Request, { params }: Params) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  await prisma.company.delete({ where: { id: params.id } })
  return NextResponse.json({ message: 'Company deleted' })
}
