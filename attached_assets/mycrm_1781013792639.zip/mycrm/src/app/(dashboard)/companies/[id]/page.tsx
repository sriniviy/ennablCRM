import { notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { formatDate, getFullName, CONTACT_STATUS_COLORS, CONTACT_STATUS_LABELS, cn } from '@/lib/utils'
import Link from 'next/link'
import { Globe, Phone, MapPin, Building2, Users, TrendingUp } from 'lucide-react'
import type { Metadata } from 'next'

interface Props { params: { id: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const co = await prisma.company.findUnique({ where: { id: params.id } })
  return { title: co?.name ?? 'Company' }
}

export default async function CompanyDetailPage({ params }: Props) {
  const company = await prisma.company.findUnique({
    where: { id: params.id },
    include: {
      contacts: {
        include: { _count: { select: { deals: true } } },
        orderBy: { createdAt: 'desc' },
      },
      deals: {
        include: { stage: true },
        orderBy: { createdAt: 'desc' },
      },
      activities: {
        orderBy: { createdAt: 'desc' },
        take: 10,
        include: { user: { select: { name: true } } },
      },
    },
  })

  if (!company) notFound()

  const totalPipeline = company.deals
    .filter((d) => !['Won', 'Lost'].includes(d.stage.name))
    .reduce((s, d) => s + (d.value ?? 0), 0)

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="border-b border-slate-200 bg-white px-6 py-5">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-indigo-100 text-indigo-700 text-lg font-bold flex items-center justify-center">
              {company.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="page-heading">{company.name}</h1>
              <div className="flex items-center gap-3 mt-1">
                {company.industry && (
                  <span className="text-sm text-slate-500">{company.industry}</span>
                )}
                {company.size && (
                  <>
                    <span className="text-slate-300">·</span>
                    <span className="text-sm text-slate-500">{company.size} employees</span>
                  </>
                )}
              </div>
            </div>
          </div>
          <button className="btn-secondary text-xs">Edit</button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-0">
        {/* Left: info */}
        <div className="lg:col-span-1 border-r border-slate-200 p-6 space-y-6 bg-white">
          {/* Contact info */}
          <section>
            <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Info</h2>
            <ul className="space-y-2.5">
              {company.website && (
                <li className="flex items-center gap-2.5 text-sm">
                  <Globe className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <a href={company.website} target="_blank" rel="noopener" className="text-teal-700 hover:underline truncate">
                    {company.domain ?? company.website}
                  </a>
                </li>
              )}
              {company.phone && (
                <li className="flex items-center gap-2.5 text-sm">
                  <Phone className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <span className="text-slate-700">{company.phone}</span>
                </li>
              )}
              {(company.city || company.country) && (
                <li className="flex items-center gap-2.5 text-sm">
                  <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <span className="text-slate-700">
                    {[company.city, company.country].filter(Boolean).join(', ')}
                  </span>
                </li>
              )}
            </ul>
          </section>

          {/* Stats */}
          <section>
            <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Overview</h2>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-50 rounded-lg p-3 text-center">
                <div className="text-xl font-semibold text-slate-900">{company.contacts.length}</div>
                <div className="text-xs text-slate-500 mt-0.5">Contacts</div>
              </div>
              <div className="bg-slate-50 rounded-lg p-3 text-center">
                <div className="text-xl font-semibold text-slate-900">{company.deals.length}</div>
                <div className="text-xs text-slate-500 mt-0.5">Deals</div>
              </div>
            </div>
            {totalPipeline > 0 && (
              <div className="bg-teal-50 rounded-lg p-3 text-center mt-3">
                <div className="text-xl font-semibold text-teal-900">
                  ${(totalPipeline / 1000).toFixed(0)}K
                </div>
                <div className="text-xs text-teal-600 mt-0.5">Open pipeline</div>
              </div>
            )}
          </section>

          {/* Created */}
          <section>
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between">
                <dt className="text-slate-400">Added</dt>
                <dd className="text-slate-700">{formatDate(company.createdAt)}</dd>
              </div>
            </dl>
          </section>
        </div>

        {/* Right: contacts + deals */}
        <div className="lg:col-span-2 p-6 space-y-6">
          {/* Contacts */}
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <Users className="h-4 w-4 text-slate-400" />
                Contacts ({company.contacts.length})
              </h2>
            </div>
            {company.contacts.length === 0 ? (
              <p className="text-sm text-slate-400">No contacts linked to this company.</p>
            ) : (
              <div className="card overflow-hidden divide-y divide-slate-100">
                {company.contacts.map((c) => (
                  <Link
                    key={c.id}
                    href={`/contacts/${c.id}`}
                    className="flex items-center gap-3 px-4 py-3 hover:bg-slate-50 transition-colors"
                  >
                    <div className="h-8 w-8 rounded-full bg-teal-100 text-teal-700 text-xs font-semibold flex items-center justify-center shrink-0">
                      {c.firstName.charAt(0)}{c.lastName.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-slate-900">{getFullName(c)}</div>
                      {c.title && <div className="text-xs text-slate-400">{c.title}</div>}
                    </div>
                    <span className={cn('badge', CONTACT_STATUS_COLORS[c.status])}>
                      {CONTACT_STATUS_LABELS[c.status]}
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </section>

          {/* Deals */}
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-slate-400" />
                Deals ({company.deals.length})
              </h2>
            </div>
            {company.deals.length === 0 ? (
              <p className="text-sm text-slate-400">No deals linked to this company.</p>
            ) : (
              <div className="card overflow-hidden divide-y divide-slate-100">
                {company.deals.map((d) => (
                  <div key={d.id} className="flex items-center gap-3 px-4 py-3">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-slate-900">{d.title}</div>
                      {d.value && (
                        <div className="text-xs text-slate-400">
                          ${d.value.toLocaleString()}
                        </div>
                      )}
                    </div>
                    <span
                      className="badge"
                      style={{ background: d.stage.color + '22', color: d.stage.color }}
                    >
                      {d.stage.name}
                    </span>
                    {d.closeDate && (
                      <span className="text-xs text-slate-400 shrink-0">
                        {formatDate(d.closeDate)}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  )
}
