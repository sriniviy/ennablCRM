import { prisma } from '@/lib/prisma'
import Header from '@/components/layout/Header'
import Link from 'next/link'
import { Plus, Globe, Users } from 'lucide-react'
import { formatRelativeTime } from '@/lib/utils'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Companies' }

interface Props {
  searchParams: { q?: string }
}

export default async function CompaniesPage({ searchParams }: Props) {
  const q = searchParams.q ?? ''

  const companies = await prisma.company.findMany({
    where: q
      ? { name: { contains: q, mode: 'insensitive' } }
      : undefined,
    orderBy: { name: 'asc' },
    include: {
      _count: { select: { contacts: true, deals: true } },
    },
  })

  return (
    <div className="flex-1 flex flex-col">
      <Header
        title="Companies"
        subtitle={`${companies.length} companies`}
        searchPlaceholder="Search companies…"
        actions={
          <button className="btn-primary">
            <Plus className="h-4 w-4" />
            Add company
          </button>
        }
      />

      <div className="flex-1 p-6">
        {companies.length === 0 ? (
          <div className="card py-24 text-center text-sm text-slate-400">
            No companies yet. Add one or import via CSV.
          </div>
        ) : (
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="table-header px-4 py-3 text-left">Company</th>
                  <th className="table-header px-4 py-3 text-left hidden md:table-cell">Industry</th>
                  <th className="table-header px-4 py-3 text-left hidden lg:table-cell">Domain</th>
                  <th className="table-header px-4 py-3 text-right">Contacts</th>
                  <th className="table-header px-4 py-3 text-right">Deals</th>
                  <th className="table-header px-4 py-3 text-left hidden xl:table-cell">Added</th>
                </tr>
              </thead>
              <tbody>
                {companies.map((co) => (
                  <tr key={co.id} className="table-row">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-lg bg-indigo-50 text-indigo-700 text-xs font-bold
                          flex items-center justify-center shrink-0">
                          {co.name.charAt(0).toUpperCase()}
                        </div>
                        <Link
                          href={`/companies/${co.id}`}
                          className="font-medium text-slate-900 hover:text-teal-700"
                        >
                          {co.name}
                        </Link>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-500 hidden md:table-cell">
                      {co.industry ?? <span className="text-slate-300">—</span>}
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      {co.domain ? (
                        <span className="flex items-center gap-1 text-slate-500">
                          <Globe className="h-3 w-3 text-slate-400" />
                          {co.domain}
                        </span>
                      ) : (
                        <span className="text-slate-300">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right text-slate-600">
                      {co._count.contacts}
                    </td>
                    <td className="px-4 py-3 text-right text-slate-600">
                      {co._count.deals}
                    </td>
                    <td className="px-4 py-3 text-slate-400 text-xs hidden xl:table-cell">
                      {formatRelativeTime(co.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
