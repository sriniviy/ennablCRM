import { auth } from '@clerk/nextjs/server'
import { redirect } from 'next/navigation'
import {
  Users, Building2, TrendingUp, CheckSquare,
  DollarSign, AlertCircle, Trophy,
} from 'lucide-react'
import { prisma } from '@/lib/prisma'
import { formatCurrency, formatNumber } from '@/lib/utils'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Dashboard' }

async function getStats() {
  const now = new Date()
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
  const endOfToday = new Date(now.setHours(23, 59, 59, 999))

  const [
    totalContacts,
    totalCompanies,
    openDealsAgg,
    tasksOverdue,
    tasksDueToday,
    wonThisMonth,
    recentActivity,
  ] = await Promise.all([
    prisma.contact.count(),
    prisma.company.count(),
    prisma.deal.aggregate({
      where: { stage: { name: { notIn: ['Won', 'Lost'] } } },
      _count: true,
      _sum: { value: true },
    }),
    prisma.task.count({
      where: { completed: false, dueDate: { lt: new Date() } },
    }),
    prisma.task.count({
      where: {
        completed: false,
        dueDate: { gte: new Date(now.setHours(0, 0, 0, 0)), lte: endOfToday },
      },
    }),
    prisma.deal.aggregate({
      where: {
        stage: { name: 'Won' },
        updatedAt: { gte: startOfMonth },
      },
      _count: true,
      _sum: { value: true },
    }),
    prisma.activity.findMany({
      take: 8,
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { name: true } },
        contact: { select: { firstName: true, lastName: true } },
        deal: { select: { title: true } },
      },
    }),
  ])

  return {
    totalContacts,
    totalCompanies,
    openDeals: openDealsAgg._count,
    pipelineValue: openDealsAgg._sum.value ?? 0,
    tasksOverdue,
    tasksDueToday,
    wonDealsThisMonth: wonThisMonth._count,
    wonValueThisMonth: wonThisMonth._sum.value ?? 0,
    recentActivity,
  }
}

export default async function DashboardPage() {
  const { userId } = auth()
  if (!userId) redirect('/sign-in')

  const stats = await getStats()

  const statCards = [
    {
      label: 'Total contacts',
      value: formatNumber(stats.totalContacts),
      icon: Users,
      color: 'text-teal-600',
      bg: 'bg-teal-50',
    },
    {
      label: 'Companies',
      value: formatNumber(stats.totalCompanies),
      icon: Building2,
      color: 'text-indigo-600',
      bg: 'bg-indigo-50',
    },
    {
      label: 'Pipeline value',
      value: formatCurrency(stats.pipelineValue),
      sub: `${stats.openDeals} open deals`,
      icon: TrendingUp,
      color: 'text-violet-600',
      bg: 'bg-violet-50',
    },
    {
      label: 'Won this month',
      value: formatCurrency(stats.wonValueThisMonth),
      sub: `${stats.wonDealsThisMonth} deals`,
      icon: Trophy,
      color: 'text-amber-600',
      bg: 'bg-amber-50',
    },
    {
      label: 'Tasks due today',
      value: stats.tasksDueToday.toString(),
      icon: CheckSquare,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
    },
    {
      label: 'Overdue tasks',
      value: stats.tasksOverdue.toString(),
      icon: AlertCircle,
      color: 'text-red-600',
      bg: 'bg-red-50',
    },
  ]

  return (
    <div className="flex-1 p-6 space-y-6">
      <div>
        <h1 className="page-heading">Good morning 👋</h1>
        <p className="page-sub">Here's what's happening with your pipeline today.</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        {statCards.map((s) => (
          <div key={s.label} className="card p-4 space-y-3">
            <div className={`inline-flex rounded-lg p-2 ${s.bg}`}>
              <s.icon className={`h-4 w-4 ${s.color}`} />
            </div>
            <div>
              <div className="text-2xl font-semibold text-slate-900">{s.value}</div>
              <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
              {s.sub && <div className="text-xs text-slate-400">{s.sub}</div>}
            </div>
          </div>
        ))}
      </div>

      {/* Recent activity */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100">
          <h2 className="text-sm font-semibold text-slate-900">Recent activity</h2>
        </div>
        {stats.recentActivity.length === 0 ? (
          <div className="py-12 text-center text-sm text-slate-400">
            No activity yet — start by adding a contact.
          </div>
        ) : (
          <ul className="divide-y divide-slate-100">
            {stats.recentActivity.map((a) => (
              <li key={a.id} className="flex items-start gap-3 px-5 py-3">
                <div className="mt-0.5 h-2 w-2 rounded-full bg-teal-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-700 truncate">{a.title}</p>
                  {a.description && (
                    <p className="text-xs text-slate-400 truncate">{a.description}</p>
                  )}
                </div>
                <span className="text-xs text-slate-400 shrink-0">
                  {new Date(a.createdAt).toLocaleDateString()}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
