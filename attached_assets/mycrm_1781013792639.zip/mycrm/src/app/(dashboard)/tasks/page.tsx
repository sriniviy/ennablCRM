import { prisma } from '@/lib/prisma'
import Header from '@/components/layout/Header'
import TaskList from '@/components/shared/TaskList'
import { Plus } from 'lucide-react'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Tasks' }

interface Props {
  searchParams: { filter?: string }
}

export default async function TasksPage({ searchParams }: Props) {
  const filter = searchParams.filter ?? 'open'

  const where =
    filter === 'completed'
      ? { completed: true }
      : filter === 'overdue'
        ? { completed: false, dueDate: { lt: new Date() } }
        : { completed: false }

  const tasks = await prisma.task.findMany({
    where,
    orderBy: [{ dueDate: 'asc' }, { priority: 'asc' }],
    include: {
      contact: { select: { id: true, firstName: true, lastName: true } },
      deal:    { select: { id: true, title: true } },
      assignee:{ select: { id: true, name: true, avatarUrl: true } },
    },
  })

  const counts = await prisma.task.groupBy({
    by: ['completed'],
    _count: true,
  })

  const overdueCount = await prisma.task.count({
    where: { completed: false, dueDate: { lt: new Date() } },
  })

  return (
    <div className="flex-1 flex flex-col">
      <Header
        title="Tasks"
        subtitle={`${tasks.length} ${filter} tasks`}
        actions={
          <button className="btn-primary">
            <Plus className="h-4 w-4" />
            Add task
          </button>
        }
      />

      <div className="flex-1 p-6">
        {/* Filter tabs */}
        <div className="flex gap-1 mb-4 border-b border-slate-200 pb-0">
          {[
            { key: 'open',      label: 'Open' },
            { key: 'overdue',   label: `Overdue${overdueCount ? ` (${overdueCount})` : ''}` },
            { key: 'completed', label: 'Completed' },
          ].map(({ key, label }) => (
            <a
              key={key}
              href={`?filter=${key}`}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                filter === key
                  ? 'border-teal-600 text-teal-700'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              {label}
            </a>
          ))}
        </div>

        <TaskList tasks={tasks as any} />
      </div>
    </div>
  )
}
