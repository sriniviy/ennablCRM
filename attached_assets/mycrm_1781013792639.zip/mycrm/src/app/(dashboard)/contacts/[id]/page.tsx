import { notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { formatDate, getFullName, CONTACT_STATUS_LABELS, CONTACT_STATUS_COLORS, cn } from '@/lib/utils'
import ActivityTimeline from '@/components/shared/ActivityTimeline'
import { Building2, Mail, Phone, Linkedin, Tag } from 'lucide-react'
import type { Metadata } from 'next'

interface Props { params: { id: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const c = await prisma.contact.findUnique({ where: { id: params.id } })
  return { title: c ? getFullName(c) : 'Contact' }
}

export default async function ContactDetailPage({ params }: Props) {
  const contact = await prisma.contact.findUnique({
    where: { id: params.id },
    include: {
      company: true,
      assignee: { select: { id: true, name: true, avatarUrl: true } },
      deals: {
        include: { stage: true },
        orderBy: { createdAt: 'desc' },
      },
      tasks: {
        where: { completed: false },
        orderBy: { dueDate: 'asc' },
        take: 5,
      },
      activities: {
        orderBy: { createdAt: 'desc' },
        take: 20,
        include: { user: { select: { name: true, avatarUrl: true } } },
      },
    },
  })

  if (!contact) notFound()

  return (
    <div className="flex-1 flex flex-col">
      {/* Header bar */}
      <div className="border-b border-slate-200 bg-white px-6 py-5">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="page-heading">{getFullName(contact)}</h1>
            <div className="flex items-center gap-2 mt-1">
              {contact.title && <span className="text-sm text-slate-500">{contact.title}</span>}
              {contact.company && (
                <>
                  <span className="text-slate-300">·</span>
                  <span className="text-sm text-slate-500">{contact.company.name}</span>
                </>
              )}
              <span className={cn('badge', CONTACT_STATUS_COLORS[contact.status])}>
                {CONTACT_STATUS_LABELS[contact.status]}
              </span>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="btn-secondary text-xs">Edit</button>
            <button className="btn-primary text-xs">Log activity</button>
          </div>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-0">
        {/* Left: details */}
        <div className="lg:col-span-1 border-r border-slate-200 p-6 space-y-6 bg-white">
          {/* Contact info */}
          <section>
            <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
              Contact info
            </h2>
            <ul className="space-y-2.5">
              {contact.email && (
                <li className="flex items-center gap-2.5 text-sm">
                  <Mail className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <a href={`mailto:${contact.email}`} className="text-teal-700 hover:underline truncate">
                    {contact.email}
                  </a>
                </li>
              )}
              {contact.phone && (
                <li className="flex items-center gap-2.5 text-sm">
                  <Phone className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <span className="text-slate-700">{contact.phone}</span>
                </li>
              )}
              {contact.company && (
                <li className="flex items-center gap-2.5 text-sm">
                  <Building2 className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <span className="text-slate-700">{contact.company.name}</span>
                </li>
              )}
              {contact.linkedIn && (
                <li className="flex items-center gap-2.5 text-sm">
                  <Linkedin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <a href={contact.linkedIn} target="_blank" rel="noopener" className="text-teal-700 hover:underline">
                    LinkedIn
                  </a>
                </li>
              )}
            </ul>
          </section>

          {/* Tags */}
          {contact.tags.length > 0 && (
            <section>
              <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                Tags
              </h2>
              <div className="flex flex-wrap gap-1.5">
                {contact.tags.map((t) => (
                  <span key={t} className="badge bg-slate-100 text-slate-600">
                    <Tag className="h-2.5 w-2.5 mr-1" />{t}
                  </span>
                ))}
              </div>
            </section>
          )}

          {/* Open deals */}
          {contact.deals.length > 0 && (
            <section>
              <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                Deals
              </h2>
              <ul className="space-y-2">
                {contact.deals.map((d) => (
                  <li key={d.id} className="flex items-center justify-between text-sm">
                    <span className="text-slate-700 truncate">{d.title}</span>
                    <span
                      className="badge ml-2 shrink-0"
                      style={{ background: d.stage.color + '22', color: d.stage.color }}
                    >
                      {d.stage.name}
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Metadata */}
          <section>
            <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
              Details
            </h2>
            <dl className="space-y-2 text-xs">
              <div className="flex justify-between">
                <dt className="text-slate-400">Added</dt>
                <dd className="text-slate-700">{formatDate(contact.createdAt)}</dd>
              </div>
              {contact.assignee && (
                <div className="flex justify-between">
                  <dt className="text-slate-400">Owner</dt>
                  <dd className="text-slate-700">{contact.assignee.name}</dd>
                </div>
              )}
            </dl>
          </section>
        </div>

        {/* Right: activity timeline */}
        <div className="lg:col-span-2 p-6">
          <ActivityTimeline activities={contact.activities as any} />
        </div>
      </div>
    </div>
  )
}
