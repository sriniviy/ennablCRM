import { prisma } from '@/lib/prisma'
import Header from '@/components/layout/Header'
import ContactsTable from '@/components/contacts/ContactsTable'
import AddContactButton from '@/components/contacts/AddContactButton'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Contacts' }

interface Props {
  searchParams: { q?: string; status?: string; page?: string }
}

export default async function ContactsPage({ searchParams }: Props) {
  const page     = Number(searchParams.page ?? 1)
  const pageSize = 25
  const q        = searchParams.q ?? ''
  const status   = searchParams.status ?? ''

  const where = {
    ...(q && {
      OR: [
        { firstName: { contains: q, mode: 'insensitive' as const } },
        { lastName:  { contains: q, mode: 'insensitive' as const } },
        { email:     { contains: q, mode: 'insensitive' as const } },
      ],
    }),
    ...(status && { status: status as any }),
  }

  const [contacts, total, companies] = await Promise.all([
    prisma.contact.findMany({
      where,
      skip: (page - 1) * pageSize,
      take: pageSize,
      orderBy: { createdAt: 'desc' },
      include: {
        company:  { select: { id: true, name: true } },
        assignee: { select: { id: true, name: true, avatarUrl: true } },
        _count:   { select: { deals: true, tasks: true } },
      },
    }),
    prisma.contact.count({ where }),
    prisma.company.findMany({ select: { id: true, name: true }, orderBy: { name: 'asc' } }),
  ])

  return (
    <div className="flex-1 flex flex-col">
      <Header
        title="Contacts"
        subtitle={`${total} total`}
        searchPlaceholder="Search by name or email…"
        actions={<AddContactButton companies={companies} />}
      />
      <div className="flex-1 p-6">
        <ContactsTable
          contacts={contacts as any}
          total={total}
          page={page}
          pageSize={pageSize}
        />
      </div>
    </div>
  )
}
