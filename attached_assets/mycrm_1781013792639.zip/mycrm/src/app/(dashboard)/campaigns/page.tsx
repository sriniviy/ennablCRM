import { prisma } from '@/lib/prisma'
import Header from '@/components/layout/Header'
import Link from 'next/link'
import { Plus, Mail, Users, MousePointerClick, Eye } from 'lucide-react'
import { formatDate, CAMPAIGN_STATUS_COLORS, cn, percent } from '@/lib/utils'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Campaigns' }

export default async function CampaignsPage() {
  const campaigns = await prisma.emailCampaign.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      _count: { select: { recipients: true } },
      recipients: {
        select: { status: true },
      },
    },
  })

  const withStats = campaigns.map((c) => {
    const sent     = c.recipients.filter((r) => r.status !== 'PENDING').length
    const opened   = c.recipients.filter((r) => ['OPENED','CLICKED'].includes(r.status)).length
    const clicked  = c.recipients.filter((r) => r.status === 'CLICKED').length
    return {
      ...c,
      stats: {
        total: c._count.recipients,
        sent,
        openRate: percent(opened, sent),
        clickRate: percent(clicked, sent),
      },
    }
  })

  return (
    <div className="flex-1 flex flex-col">
      <Header
        title="Campaigns"
        subtitle={`${campaigns.length} campaigns`}
        actions={
          <Link href="/campaigns/new" className="btn-primary">
            <Plus className="h-4 w-4" />
            New campaign
          </Link>
        }
      />

      <div className="flex-1 p-6">
        {campaigns.length === 0 ? (
          <div className="card py-24 text-center">
            <Mail className="h-8 w-8 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500 text-sm">No campaigns yet.</p>
            <Link href="/campaigns/new" className="btn-primary mt-4 inline-flex">
              Create your first campaign
            </Link>
          </div>
        ) : (
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="table-header px-4 py-3 text-left">Campaign</th>
                  <th className="table-header px-4 py-3 text-left">Status</th>
                  <th className="table-header px-4 py-3 text-right">Recipients</th>
                  <th className="table-header px-4 py-3 text-right">Open rate</th>
                  <th className="table-header px-4 py-3 text-right">Click rate</th>
                  <th className="table-header px-4 py-3 text-left">Date</th>
                </tr>
              </thead>
              <tbody>
                {withStats.map((c) => (
                  <tr key={c.id} className="table-row">
                    <td className="px-4 py-3">
                      <Link href={`/campaigns/${c.id}`} className="font-medium text-slate-900 hover:text-teal-700">
                        {c.name}
                      </Link>
                      <div className="text-xs text-slate-400 mt-0.5 truncate max-w-xs">{c.subject}</div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={cn('badge', CAMPAIGN_STATUS_COLORS[c.status])}>
                        {c.status.charAt(0) + c.status.slice(1).toLowerCase()}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right text-slate-600">
                      <span className="flex items-center justify-end gap-1">
                        <Users className="h-3 w-3 text-slate-400" />
                        {c.stats.total}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className="flex items-center justify-end gap-1 text-teal-700">
                        <Eye className="h-3 w-3" />
                        {c.stats.openRate}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className="flex items-center justify-end gap-1 text-indigo-700">
                        <MousePointerClick className="h-3 w-3" />
                        {c.stats.clickRate}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-400 text-xs">
                      {c.sentAt ? formatDate(c.sentAt) : formatDate(c.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
