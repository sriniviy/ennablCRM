'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Send, Save } from 'lucide-react'
import Link from 'next/link'
import EmailBuilder, { buildEmailHtml } from '@/components/campaigns/EmailBuilder'
import { Field, Input } from '@/components/shared/FormField'
import { useToast } from '@/components/shared/Toast'
import { CONTACT_STATUS_LABELS } from '@/lib/utils'

// Note: this is a client component — data is fetched via API on submit.
// To pre-populate contacts, make this a server component wrapper + pass props.

interface Block {
  id: string
  type: string
  text?: string
  url?: string
  align?: string
  color?: string
}

export default function NewCampaignPage() {
  const router    = useRouter()
  const { toast } = useToast()

  const [saving,   setSaving]   = useState(false)
  const [error,    setError]    = useState('')

  const [meta, setMeta] = useState({
    name:      '',
    subject:   '',
    fromName:  '',
    fromEmail: '',
  })

  const [blocks,          setBlocks]         = useState<Block[]>([
    { id: '1', type: 'heading', text: 'Hello there 👋', align: 'left' },
    { id: '2', type: 'text',    text: 'Write your campaign message here. Keep it personal, short, and clear.',  align: 'left' },
    { id: '3', type: 'button',  text: 'Take action', url: 'https://', color: '#0d9488', align: 'center' },
  ])
  const [recipientFilter, setRecipientFilter] = useState<string>('ALL')

  function setMf(k: keyof typeof meta, v: string) {
    setMeta((m) => ({ ...m, [k]: v }))
  }

  async function handleSave(sendNow = false) {
    if (!meta.name || !meta.subject || !meta.fromName || !meta.fromEmail) {
      setError('Fill in the campaign name, subject, and sender details')
      return
    }
    if (blocks.length === 0) {
      setError('Add at least one content block')
      return
    }

    setSaving(true)
    setError('')

    try {
      const htmlContent = buildEmailHtml(blocks as any, meta.subject)

      // Fetch recipients based on filter
      let contactIds: string[] = []
      if (recipientFilter !== 'ALL') {
        const res = await fetch(`/api/contacts?status=${recipientFilter}&pageSize=1000`)
        const data = await res.json()
        contactIds = (data.data ?? []).map((c: any) => c.id)
      }

      // Create campaign
      const createRes = await fetch('/api/campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...meta,
          htmlContent,
          contactIds: recipientFilter === 'ALL' ? undefined : contactIds,
        }),
      })
      const createData = await createRes.json()
      if (!createRes.ok) throw new Error(createData.error ?? 'Failed to create campaign')

      if (sendNow) {
        const sendRes = await fetch('/api/campaigns', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: createData.data.id, action: 'send' }),
        })
        const sendData = await sendRes.json()
        if (!sendRes.ok) throw new Error(sendData.error ?? 'Send failed')
        toast(`Campaign sent to ${sendData.data.sent} contacts`)
      } else {
        toast('Campaign saved as draft')
      }

      router.push('/campaigns')
    } catch (err: any) {
      setError(err.message ?? 'Something went wrong')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-white">
        <div className="flex items-center gap-3">
          <Link href="/campaigns" className="btn-ghost p-1.5">
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <h1 className="text-sm font-semibold text-slate-900">New campaign</h1>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn-secondary" disabled={saving} onClick={() => handleSave(false)}>
            <Save className="h-4 w-4" />
            Save draft
          </button>
          <button className="btn-primary" disabled={saving} onClick={() => handleSave(true)}>
            <Send className="h-4 w-4" />
            {saving ? 'Sending…' : 'Send now'}
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto p-6 space-y-6">
          {error && (
            <div className="rounded-lg bg-red-50 text-red-700 text-sm px-4 py-3 border border-red-200">
              {error}
            </div>
          )}

          {/* Campaign metadata */}
          <div className="card p-5 space-y-4">
            <h2 className="text-sm font-semibold text-slate-900">Campaign details</h2>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Campaign name" required>
                <Input value={meta.name} onChange={(e) => setMf('name', e.target.value)} placeholder="May newsletter" />
              </Field>
              <Field label="Email subject" required>
                <Input value={meta.subject} onChange={(e) => setMf('subject', e.target.value)} placeholder="Here's what's new this month" />
              </Field>
              <Field label="From name" required>
                <Input value={meta.fromName} onChange={(e) => setMf('fromName', e.target.value)} placeholder="Acme Team" />
              </Field>
              <Field label="From email" required>
                <Input type="email" value={meta.fromEmail} onChange={(e) => setMf('fromEmail', e.target.value)} placeholder="hello@yourdomain.com" />
              </Field>
            </div>
          </div>

          {/* Recipients */}
          <div className="card p-5 space-y-3">
            <h2 className="text-sm font-semibold text-slate-900">Recipients</h2>
            <p className="text-xs text-slate-500">Send to all contacts, or filter by status.</p>
            <div className="flex flex-wrap gap-2">
              {[
                { key: 'ALL',         label: 'All contacts' },
                ...Object.entries(CONTACT_STATUS_LABELS).map(([k, v]) => ({ key: k, label: v })),
              ].map(({ key, label }) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setRecipientFilter(key)}
                  className={`btn text-xs py-1.5 px-3 ${
                    recipientFilter === key ? 'btn-primary' : 'btn-secondary'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Email builder */}
          <div className="card p-5 space-y-3">
            <h2 className="text-sm font-semibold text-slate-900">Email content</h2>
            <EmailBuilder
              value={blocks as any}
              onChange={setBlocks as any}
              subject={meta.subject || '(Preview)'}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
