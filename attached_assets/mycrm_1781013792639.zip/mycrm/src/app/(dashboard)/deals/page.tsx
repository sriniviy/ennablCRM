import { prisma } from '@/lib/prisma'
import Header from '@/components/layout/Header'
import KanbanBoard from '@/components/deals/KanbanBoard'
import AddDealButton from '@/components/deals/AddDealButton'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Pipeline' }

export default async function DealsPage() {
  const [stages, contacts, companies] = await Promise.all([
    prisma.dealStage.findMany({
      orderBy: { order: 'asc' },
      include: {
        deals: {
          orderBy: { order: 'asc' },
          include: {
            contact:  { select: { id: true, firstName: true, lastName: true, email: true } },
            company:  { select: { id: true, name: true } },
            assignee: { select: { id: true, name: true, avatarUrl: true } },
          },
        },
      },
    }),
    prisma.contact.findMany({
      select: { id: true, firstName: true, lastName: true },
      orderBy: { firstName: 'asc' },
      take: 200,
    }),
    prisma.company.findMany({
      select: { id: true, name: true },
      orderBy: { name: 'asc' },
    }),
  ])

  const totalValue = stages
    .flatMap((s) => s.deals)
    .filter((d: any) => !['Won', 'Lost'].includes(d.stage?.name ?? ''))
    .reduce((sum: number, d: any) => sum + (d.value ?? 0), 0)

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Pipeline"
        subtitle={`$${(totalValue / 1000).toFixed(0)}K in open deals`}
        actions={
          <AddDealButton
            stages={stages.map(s => ({ id: s.id, name: s.name, color: s.color }))}
            contacts={contacts}
            companies={companies}
          />
        }
      />
      <div className="flex-1 overflow-hidden">
        <KanbanBoard initialColumns={stages as any} />
      </div>
    </div>
  )
}
