import type {
  Contact,
  Company,
  Deal,
  DealStage,
  Task,
  Activity,
  EmailCampaign,
  CampaignContact,
  User,
  ContactStatus,
  Priority,
  TaskType,
  ActivityType,
  CampaignStatus,
  SendStatus,
} from '@prisma/client'

// Re-export Prisma enums for use throughout the app
export type {
  ContactStatus,
  Priority,
  TaskType,
  ActivityType,
  CampaignStatus,
  SendStatus,
}

// ─── Enriched types (with relations) ─────────────────────────────────────────

export type ContactWithRelations = Contact & {
  company?: Company | null
  assignee?: Pick<User, 'id' | 'name' | 'avatarUrl'> | null
  _count?: { deals: number; tasks: number; activities: number }
}

export type DealWithRelations = Deal & {
  stage: DealStage
  contact?: Pick<Contact, 'id' | 'firstName' | 'lastName' | 'email'> | null
  company?: Pick<Company, 'id' | 'name'> | null
  assignee?: Pick<User, 'id' | 'name' | 'avatarUrl'> | null
}

export type TaskWithRelations = Task & {
  contact?: Pick<Contact, 'id' | 'firstName' | 'lastName'> | null
  deal?: Pick<Deal, 'id' | 'title'> | null
  assignee?: Pick<User, 'id' | 'name' | 'avatarUrl'> | null
}

export type ActivityWithRelations = Activity & {
  user?: Pick<User, 'id' | 'name' | 'avatarUrl'> | null
  contact?: Pick<Contact, 'id' | 'firstName' | 'lastName'> | null
  deal?: Pick<Deal, 'id' | 'title'> | null
}

export type CampaignWithStats = EmailCampaign & {
  _count: { recipients: number }
  stats?: {
    sent: number
    opened: number
    clicked: number
    openRate: number
    clickRate: number
  }
}

// ─── Kanban pipeline type ─────────────────────────────────────────────────────

export type PipelineColumn = DealStage & {
  deals: DealWithRelations[]
}

// ─── Dashboard stats ──────────────────────────────────────────────────────────

export type DashboardStats = {
  totalContacts: number
  totalCompanies: number
  openDeals: number
  pipelineValue: number
  tasksOverdue: number
  tasksDueToday: number
  wonDealsThisMonth: number
  wonValueThisMonth: number
}

// ─── Form types ───────────────────────────────────────────────────────────────

export type ContactFormData = {
  firstName: string
  lastName: string
  email?: string
  phone?: string
  title?: string
  status: ContactStatus
  companyId?: string
  tags?: string[]
  notes?: string
  linkedIn?: string
}

export type DealFormData = {
  title: string
  value?: number
  currency?: string
  probability?: number
  closeDate?: string
  stageId: string
  contactId?: string
  companyId?: string
  notes?: string
}

export type TaskFormData = {
  title: string
  description?: string
  dueDate?: string
  priority: Priority
  type: TaskType
  contactId?: string
  dealId?: string
  assigneeId?: string
}

export type CampaignFormData = {
  name: string
  subject: string
  fromName: string
  fromEmail: string
  htmlContent: string
  textContent?: string
}

// ─── API response types ───────────────────────────────────────────────────────

export type ApiResponse<T> = {
  data?: T
  error?: string
  message?: string
}

export type PaginatedResponse<T> = {
  data: T[]
  total: number
  page: number
  pageSize: number
  hasMore: boolean
}
