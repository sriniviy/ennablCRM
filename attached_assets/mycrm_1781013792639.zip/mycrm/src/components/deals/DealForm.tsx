'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Modal from '@/components/shared/Modal'
import { Field, Input, Select, TextArea } from '@/components/shared/FormField'
import { useToast } from '@/components/shared/Toast'
import type { DealFormData } from '@/types'

interface DealStage { id: string; name: string; color: string }
interface Contact    { id: string; firstName: string; lastName: string }
interface Company    { id: string; name: string }

interface Props {
  open: boolean
  onClose: () => void
  stages:    DealStage[]
  contacts?: Contact[]
  companies?: Company[]
  initialData?: Partial<DealFormData> & { id?: string }
  onSuccess?: (deal: any) => void
}

const DEFAULT: DealFormData = {
  title:       '',
  value:       undefined,
  currency:    'USD',
  probability: 50,
  closeDate:   '',
  stageId:     '',
  contactId:   '',
  companyId:   '',
  notes:       '',
}

export default function DealForm({
  open, onClose, stages, contacts = [], companies = [], initialData, onSuccess,
}: Props) {
  const router    = useRouter()
  const { toast } = useToast()
  const isEdit    = !!initialData?.id

  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')
  const [form,    setForm]    = useState<DealFormData>({
    ...DEFAULT,
    stageId: stages[0]?.id ?? '',
    ...initialData,
  })

  function set<K extends keyof DealFormData>(key: K, value: DealFormData[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.title.trim() || !form.stageId) return

    setLoading(true)
    setError('')

    try {
      const url    = isEdit ? `/api/deals/${initialData!.id}` : '/api/deals'
      const method = isEdit ? 'PATCH' : 'POST'

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          value:     form.value ? Number(form.value) : undefined,
          closeDate: form.closeDate || undefined,
          contactId: form.contactId || undefined,
          companyId: form.companyId || undefined,
        }),
      })

      const data = await res.json()
      if (!res.ok) {
        setError(data.error ?? 'Something went wrong')
        return
      }

      toast(isEdit ? 'Deal updated' : 'Deal created')
      onSuccess?.(data.data)
      onClose()
      router.refresh()
    } catch {
      setError('Network error — please try again')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={isEdit ? 'Edit deal' : 'Add deal'}
      size="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="rounded-lg bg-red-50 text-red-700 text-sm px-3 py-2 border border-red-200">
            {error}
          </div>
        )}

        {/* Title */}
        <Field label="Deal name" required>
          <Input
            value={form.title}
            onChange={(e) => set('title', e.target.value)}
            placeholder="Acme Corp — Enterprise plan"
            required
            autoFocus
          />
        </Field>

        {/* Value + Currency */}
        <div className="grid grid-cols-3 gap-3">
          <Field label="Value" className="col-span-2">
            <Input
              type="number"
              min={0}
              step={0.01}
              value={form.value ?? ''}
              onChange={(e) => set('value', e.target.value ? Number(e.target.value) : undefined)}
              placeholder="10000"
            />
          </Field>
          <Field label="Currency">
            <Select
              value={form.currency}
              onChange={(e) => set('currency', e.target.value)}
            >
              {['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'JPY'].map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </Select>
          </Field>
        </div>

        {/* Stage */}
        <Field label="Stage" required>
          <Select
            value={form.stageId}
            onChange={(e) => set('stageId', e.target.value)}
            required
          >
            {stages.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </Select>
        </Field>

        {/* Close date + Probability */}
        <div className="grid grid-cols-2 gap-3">
          <Field label="Expected close">
            <Input
              type="date"
              value={form.closeDate ?? ''}
              onChange={(e) => set('closeDate', e.target.value)}
            />
          </Field>
          <Field label={`Probability: ${form.probability}%`}>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={form.probability ?? 50}
              onChange={(e) => set('probability', Number(e.target.value))}
              className="w-full h-2 accent-teal-600 mt-2"
            />
          </Field>
        </div>

        {/* Contact */}
        {contacts.length > 0 && (
          <Field label="Contact">
            <Select
              value={form.contactId ?? ''}
              onChange={(e) => set('contactId', e.target.value)}
            >
              <option value="">— None —</option>
              {contacts.map((c) => (
                <option key={c.id} value={c.id}>{c.firstName} {c.lastName}</option>
              ))}
            </Select>
          </Field>
        )}

        {/* Company */}
        {companies.length > 0 && (
          <Field label="Company">
            <Select
              value={form.companyId ?? ''}
              onChange={(e) => set('companyId', e.target.value)}
            >
              <option value="">— None —</option>
              {companies.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </Select>
          </Field>
        )}

        {/* Notes */}
        <Field label="Notes">
          <TextArea
            rows={2}
            value={form.notes ?? ''}
            onChange={(e) => set('notes', e.target.value)}
            placeholder="Key context about this deal…"
          />
        </Field>

        <div className="flex justify-end gap-2 pt-1">
          <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          <button type="submit" disabled={loading} className="btn-primary">
            {loading ? 'Saving…' : isEdit ? 'Save changes' : 'Create deal'}
          </button>
        </div>
      </form>
    </Modal>
  )
}
