'use client'

import { useState, useCallback } from 'react'
import { DragDropContext, Droppable, Draggable, type DropResult } from '@hello-pangea/dnd'
import { formatCurrency, getFullName } from '@/lib/utils'
import type { PipelineColumn, DealWithRelations } from '@/types'
import { DollarSign, Calendar, User, Plus } from 'lucide-react'

interface Props {
  initialColumns: PipelineColumn[]
}

export default function KanbanBoard({ initialColumns }: Props) {
  const [columns, setColumns] = useState<PipelineColumn[]>(initialColumns)

  const onDragEnd = useCallback(
    async (result: DropResult) => {
      const { source, destination, draggableId } = result
      if (!destination) return
      if (source.droppableId === destination.droppableId && source.index === destination.index) return

      const srcCol = columns.find((c) => c.id === source.droppableId)!
      const dstCol = columns.find((c) => c.id === destination.droppableId)!
      const deal   = srcCol.deals[source.index]

      // Optimistic update
      const newCols = columns.map((col) => {
        if (col.id === source.droppableId) {
          const deals = [...col.deals]
          deals.splice(source.index, 1)
          return { ...col, deals }
        }
        if (col.id === destination.droppableId) {
          const deals = [...col.deals]
          deals.splice(destination.index, 0, { ...deal, stageId: destination.droppableId, stage: dstCol })
          return { ...col, deals }
        }
        return col
      })
      setColumns(newCols)

      // Persist to API
      await fetch(`/api/deals/${draggableId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stageId: destination.droppableId,
          order: destination.index,
        }),
      })
    },
    [columns]
  )

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex gap-3 h-full overflow-x-auto px-6 py-4 pb-6">
        {columns.map((col) => {
          const colValue = col.deals.reduce((s, d) => s + (d.value ?? 0), 0)
          return (
            <div
              key={col.id}
              className="flex flex-col w-64 shrink-0 bg-slate-50 rounded-xl border border-slate-200"
            >
              {/* Column header */}
              <div className="flex items-center justify-between px-3 py-2.5 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <div
                    className="h-2 w-2 rounded-full"
                    style={{ background: col.color }}
                  />
                  <span className="text-xs font-semibold text-slate-700">{col.name}</span>
                  <span className="text-xs text-slate-400 bg-white border border-slate-200 rounded-full px-1.5">
                    {col.deals.length}
                  </span>
                </div>
                <button className="text-slate-400 hover:text-slate-700 transition-colors">
                  <Plus className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Column total */}
              {colValue > 0 && (
                <div className="px-3 py-1.5 text-xs text-slate-500 bg-slate-50 border-b border-slate-100">
                  {formatCurrency(colValue)}
                </div>
              )}

              {/* Deal cards */}
              <Droppable droppableId={col.id}>
                {(provided, snapshot) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className={`flex-1 overflow-y-auto p-2 space-y-2 min-h-[120px] transition-colors ${
                      snapshot.isDraggingOver ? 'bg-teal-50' : ''
                    }`}
                  >
                    {col.deals.map((deal, idx) => (
                      <DealCard key={deal.id} deal={deal} index={idx} />
                    ))}
                    {provided.placeholder}

                    {col.deals.length === 0 && !snapshot.isDraggingOver && (
                      <p className="text-xs text-slate-400 text-center py-6">
                        Drop a deal here
                      </p>
                    )}
                  </div>
                )}
              </Droppable>
            </div>
          )
        })}
      </div>
    </DragDropContext>
  )
}

// ─── Deal Card ────────────────────────────────────────────────────────────────

function DealCard({ deal, index }: { deal: DealWithRelations; index: number }) {
  const isOverdue =
    deal.closeDate && new Date(deal.closeDate) < new Date()

  return (
    <Draggable draggableId={deal.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          className={`bg-white rounded-lg border p-3 text-sm space-y-2 cursor-grab active:cursor-grabbing
            transition-shadow ${snapshot.isDragging ? 'shadow-lg border-teal-300' : 'border-slate-200 hover:shadow-sm'}`}
        >
          {/* Title */}
          <p className="font-medium text-slate-900 leading-tight">{deal.title}</p>

          {/* Value */}
          {deal.value != null && (
            <div className="flex items-center gap-1 text-xs text-slate-500">
              <DollarSign className="h-3 w-3 text-slate-400" />
              {formatCurrency(deal.value, deal.currency)}
            </div>
          )}

          {/* Contact */}
          {deal.contact && (
            <div className="flex items-center gap-1 text-xs text-slate-500">
              <User className="h-3 w-3 text-slate-400" />
              {getFullName(deal.contact)}
            </div>
          )}

          {/* Close date */}
          {deal.closeDate && (
            <div className={`flex items-center gap-1 text-xs ${isOverdue ? 'text-red-500' : 'text-slate-500'}`}>
              <Calendar className="h-3 w-3" />
              {new Date(deal.closeDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </div>
          )}

          {/* Probability */}
          {deal.probability != null && (
            <div className="h-1 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-teal-400 rounded-full transition-all"
                style={{ width: `${deal.probability}%` }}
              />
            </div>
          )}
        </div>
      )}
    </Draggable>
  )
}
