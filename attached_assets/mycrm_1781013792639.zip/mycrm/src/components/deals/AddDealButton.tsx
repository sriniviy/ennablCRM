'use client'

import { useState } from 'react'
import { Plus } from 'lucide-react'
import DealForm from './DealForm'

interface Props {
  stages:    { id: string; name: string; color: string }[]
  contacts?: { id: string; firstName: string; lastName: string }[]
  companies?: { id: string; name: string }[]
}

export default function AddDealButton({ stages, contacts = [], companies = [] }: Props) {
  const [open, setOpen] = useState(false)

  return (
    <>
      <button onClick={() => setOpen(true)} className="btn-primary">
        <Plus className="h-4 w-4" />
        Add deal
      </button>

      <DealForm
        open={open}
        onClose={() => setOpen(false)}
        stages={stages}
        contacts={contacts}
        companies={companies}
      />
    </>
  )
}
