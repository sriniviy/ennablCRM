'use client'

import { useState, useCallback } from 'react'
import {
  Type, AlignLeft, MousePointer, Minus, Plus, Trash2,
  ChevronUp, ChevronDown, Eye, Code, GripVertical,
} from 'lucide-react'
import { cn } from '@/lib/utils'

// ─── Block types ───────────────────────────────────────────────────────────

type BlockType = 'heading' | 'subheading' | 'text' | 'button' | 'divider' | 'spacer'

interface Block {
  id:      string
  type:    BlockType
  text?:   string
  url?:    string
  align?:  'left' | 'center' | 'right'
  color?:  string
}

// ─── HTML export ──────────────────────────────────────────────────────────

function renderBlockHtml(block: Block): string {
  const align = block.align ?? 'left'
  const td    = `style="text-align:${align};padding:0 0 16px;"`

  switch (block.type) {
    case 'heading':
      return `<tr><td ${td}><h1 style="margin:0;font-size:28px;font-weight:700;color:#0f172a;line-height:1.3">${block.text ?? ''}</h1></td></tr>`
    case 'subheading':
      return `<tr><td ${td}><h2 style="margin:0;font-size:20px;font-weight:600;color:#1e293b;line-height:1.4">${block.text ?? ''}</h2></td></tr>`
    case 'text':
      return `<tr><td ${td}><p style="margin:0;font-size:15px;color:#475569;line-height:1.7">${(block.text ?? '').replace(/\n/g, '<br/>')}</p></td></tr>`
    case 'button': {
      const bg  = block.color ?? '#0d9488'
      const btn = `<a href="${block.url ?? '#'}" style="display:inline-block;background:${bg};color:#fff;font-size:14px;font-weight:600;padding:12px 28px;border-radius:8px;text-decoration:none">${block.text ?? 'Click here'}</a>`
      return `<tr><td style="text-align:${align};padding:8px 0 24px;">${btn}</td></tr>`
    }
    case 'divider':
      return `<tr><td style="padding:8px 0"><hr style="border:none;border-top:1px solid #e2e8f0;margin:0"/></td></tr>`
    case 'spacer':
      return `<tr><td style="padding:12px 0"></td></tr>`
    default:
      return ''
  }
}

export function buildEmailHtml(blocks: Block[], subject: string): string {
  const bodyRows = blocks.map(renderBlockHtml).join('\n')
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>${subject}</title>
</head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0">
          <tr><td style="padding:32px 40px">
            <table width="100%" cellpadding="0" cellspacing="0">
              ${bodyRows}
              <tr><td style="padding-top:16px;border-top:1px solid #f1f5f9">
                <p style="margin:0;font-size:12px;color:#94a3b8;text-align:center">
                  You're receiving this because you're a contact in our CRM.<br/>
                  <a href="{{{unsubscribe_url}}}" style="color:#64748b">Unsubscribe</a>
                </p>
              </td></tr>
            </table>
          </td></tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`
}

// ─── Block definition palette ─────────────────────────────────────────────

const BLOCK_DEFS: { type: BlockType; label: string; icon: React.ElementType; defaults: Partial<Block> }[] = [
  { type: 'heading',    label: 'Heading',    icon: Type,           defaults: { text: 'Your headline here', align: 'left' } },
  { type: 'subheading', label: 'Subheading', icon: Type,           defaults: { text: 'Section subheading', align: 'left' } },
  { type: 'text',       label: 'Text',       icon: AlignLeft,      defaults: { text: 'Write your message here. Keep it concise and clear.', align: 'left' } },
  { type: 'button',     label: 'Button',     icon: MousePointer,   defaults: { text: 'Get started', url: 'https://', color: '#0d9488', align: 'center' } },
  { type: 'divider',    label: 'Divider',    icon: Minus,          defaults: {} },
  { type: 'spacer',     label: 'Spacer',     icon: () => <div className="h-px w-full"/>, defaults: {} },
]

// ─── Block editor components ──────────────────────────────────────────────

interface BlockEditorProps {
  block:    Block
  onChange: (b: Block) => void
}

function BlockEditor({ block, onChange }: BlockEditorProps) {
  const set = (k: keyof Block, v: any) => onChange({ ...block, [k]: v })

  const ALIGN_OPTS: { value: 'left' | 'center' | 'right'; label: string }[] = [
    { value: 'left', label: 'L' },
    { value: 'center', label: 'C' },
    { value: 'right', label: 'R' },
  ]

  switch (block.type) {
    case 'heading':
    case 'subheading':
      return (
        <div className="space-y-2">
          <input
            className="input text-sm w-full font-semibold"
            value={block.text ?? ''}
            onChange={(e) => set('text', e.target.value)}
            placeholder="Heading text…"
          />
          <div className="flex gap-1">
            {ALIGN_OPTS.map((o) => (
              <button
                key={o.value}
                type="button"
                onClick={() => set('align', o.value)}
                className={cn('px-2.5 py-1 text-xs rounded font-medium border transition-colors',
                  block.align === o.value ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                )}
              >{o.label}</button>
            ))}
          </div>
        </div>
      )

    case 'text':
      return (
        <div className="space-y-2">
          <textarea
            className="input text-sm w-full resize-y min-h-[80px]"
            value={block.text ?? ''}
            onChange={(e) => set('text', e.target.value)}
            placeholder="Your text content…"
          />
          <div className="flex gap-1">
            {ALIGN_OPTS.map((o) => (
              <button
                key={o.value}
                type="button"
                onClick={() => set('align', o.value)}
                className={cn('px-2.5 py-1 text-xs rounded font-medium border transition-colors',
                  block.align === o.value ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                )}
              >{o.label}</button>
            ))}
          </div>
        </div>
      )

    case 'button':
      return (
        <div className="space-y-2">
          <input className="input text-sm w-full" value={block.text ?? ''} onChange={(e) => set('text', e.target.value)} placeholder="Button label" />
          <input className="input text-sm w-full" value={block.url ?? ''} onChange={(e) => set('url', e.target.value)} placeholder="https://..." type="url" />
          <div className="flex items-center gap-3">
            <label className="text-xs text-slate-500">Color</label>
            <input type="color" value={block.color ?? '#0d9488'} onChange={(e) => set('color', e.target.value)} className="h-7 w-14 rounded border border-slate-200 cursor-pointer" />
            <div className="flex gap-1 ml-2">
              {ALIGN_OPTS.map((o) => (
                <button
                  key={o.value}
                  type="button"
                  onClick={() => set('align', o.value)}
                  className={cn('px-2.5 py-1 text-xs rounded font-medium border',
                    block.align === o.value ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  )}
                >{o.label}</button>
              ))}
            </div>
          </div>
        </div>
      )

    case 'divider':
      return <p className="text-xs text-slate-400 py-1 text-center">— Horizontal divider —</p>

    case 'spacer':
      return <p className="text-xs text-slate-400 py-1 text-center">— Vertical spacer (24px) —</p>

    default:
      return null
  }
}

// ─── Main EmailBuilder export ─────────────────────────────────────────────

interface EmailBuilderProps {
  value:    Block[]
  onChange: (blocks: Block[]) => void
  subject?: string
}

export default function EmailBuilder({ value: blocks, onChange, subject = '(Preview)' }: EmailBuilderProps) {
  const [tab, setTab] = useState<'edit' | 'preview' | 'html'>('edit')

  function addBlock(type: BlockType) {
    const def  = BLOCK_DEFS.find((d) => d.type === type)!
    const newB: Block = { id: Math.random().toString(36).slice(2), type, ...def.defaults }
    onChange([...blocks, newB])
  }

  function updateBlock(id: string, updated: Block) {
    onChange(blocks.map((b) => (b.id === id ? updated : b)))
  }

  function removeBlock(id: string) {
    onChange(blocks.filter((b) => b.id !== id))
  }

  function moveBlock(id: string, dir: -1 | 1) {
    const idx = blocks.findIndex((b) => b.id === id)
    if (idx < 0) return
    const next = idx + dir
    if (next < 0 || next >= blocks.length) return
    const copy = [...blocks]
    ;[copy[idx], copy[next]] = [copy[next], copy[idx]]
    onChange(copy)
  }

  const previewHtml = buildEmailHtml(blocks, subject)

  return (
    <div className="space-y-3">
      {/* Tabs */}
      <div className="flex gap-1 border-b border-slate-200">
        {[
          { key: 'edit',    label: 'Edit',    icon: Type },
          { key: 'preview', label: 'Preview', icon: Eye },
          { key: 'html',    label: 'HTML',    icon: Code },
        ].map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key as any)}
            className={cn(
              'flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-colors -mb-px',
              tab === key
                ? 'border-teal-600 text-teal-700'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            )}
          >
            <Icon className="h-3.5 w-3.5" />
            {label}
          </button>
        ))}
      </div>

      {/* Edit tab */}
      {tab === 'edit' && (
        <div className="space-y-3">
          {/* Block list */}
          {blocks.length === 0 ? (
            <div className="border-2 border-dashed border-slate-200 rounded-xl py-10 text-center text-sm text-slate-400">
              Add your first block below
            </div>
          ) : (
            <div className="space-y-2">
              {blocks.map((block, idx) => (
                <div key={block.id} className="group border border-slate-200 rounded-xl bg-white">
                  <div className="flex items-center gap-2 px-3 py-2 border-b border-slate-100 bg-slate-50 rounded-t-xl">
                    <GripVertical className="h-3.5 w-3.5 text-slate-300" />
                    <span className="text-xs font-medium text-slate-500 capitalize flex-1">
                      {block.type}
                    </span>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button type="button" onClick={() => moveBlock(block.id, -1)} disabled={idx === 0}
                        className="p-1 text-slate-400 hover:text-slate-700 disabled:opacity-30">
                        <ChevronUp className="h-3.5 w-3.5" />
                      </button>
                      <button type="button" onClick={() => moveBlock(block.id, 1)} disabled={idx === blocks.length - 1}
                        className="p-1 text-slate-400 hover:text-slate-700 disabled:opacity-30">
                        <ChevronDown className="h-3.5 w-3.5" />
                      </button>
                      <button type="button" onClick={() => removeBlock(block.id)}
                        className="p-1 text-slate-400 hover:text-red-500">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="p-3">
                    <BlockEditor block={block} onChange={(b) => updateBlock(block.id, b)} />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Add block row */}
          <div>
            <p className="text-xs text-slate-400 mb-2">Add block</p>
            <div className="flex flex-wrap gap-2">
              {BLOCK_DEFS.map(({ type, label, icon: Icon }) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => addBlock(type)}
                  className="flex items-center gap-1.5 btn-secondary text-xs py-1.5 px-3"
                >
                  <Icon className="h-3 w-3" />
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Preview tab */}
      {tab === 'preview' && (
        <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-100">
          <iframe
            srcDoc={previewHtml}
            className="w-full"
            style={{ height: 480, border: 'none' }}
            title="Email preview"
            sandbox="allow-same-origin"
          />
        </div>
      )}

      {/* HTML tab */}
      {tab === 'html' && (
        <div className="relative">
          <pre className="bg-slate-900 text-slate-100 text-xs p-4 rounded-xl overflow-auto max-h-96 leading-relaxed">
            <code>{previewHtml}</code>
          </pre>
          <button
            type="button"
            onClick={() => navigator.clipboard.writeText(previewHtml)}
            className="absolute top-3 right-3 btn-ghost text-xs bg-slate-800 text-slate-300 hover:bg-slate-700"
          >
            Copy
          </button>
        </div>
      )}
    </div>
  )
}
