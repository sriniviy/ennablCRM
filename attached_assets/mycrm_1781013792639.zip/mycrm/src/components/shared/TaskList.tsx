'use client'

import { useState } from 'react'
import { formatDate, isOverdue, getFullName, PRIORITY_COLORS, PRIORITY_LABELS, TASK_TYPE_LABELS, cn } from '@/lib/utils'
import { CheckCircle2, Circle, Phone, Mail, Calendar, Users, TrendingUp, Clock } from 'lucide-react'
import type { TaskWithRelations } from '@/types'

const TASK_TYPE_ICONS: Record<string, React.ElementType> = {
  TODO:     Circle,
  CALL:     Phone,
  EMAIL:    Mail,
  MEETING:  Calendar,
  FOLLOW_UP:Clock,
}

interface Props {
  tasks: TaskWithRelations[]
}

export default function TaskList({ tasks }: Props) {
  const [completing, setCompleting] = useState<string | null>(null)

  async function toggleComplete(taskId: string, completed: boolean) {
    setCompleting(taskId)
    await fetch(`/api/tasks/${taskId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ completed: !completed }),
    })
    setCompleting(null)
    window.location.reload()
  }

  if (tasks.length === 0) {
    return (
      <div className="card py-16 text-center text-sm text-slate-400">
        No tasks here — you're all caught up!
      </div>
    )
  }

  return (
    <div className="card overflow-hidden divide-y divide-slate-100">
      {tasks.map((task) => {
        const Icon = TASK_TYPE_ICONS[task.type] ?? Circle
        const overdue = isOverdue(task.dueDate)

        return (
          <div key={task.id} className="flex items-start gap-3 px-4 py-3 hover:bg-slate-50 transition-colors">
            {/* Complete toggle */}
            <button
              onClick={() => toggleComplete(task.id, task.completed)}
              disabled={completing === task.id}
              className="mt-0.5 text-slate-300 hover:text-teal-500 transition-colors shrink-0"
              aria-label={task.completed ? 'Mark incomplete' : 'Mark complete'}
            >
              {task.completed ? (
                <CheckCircle2 className="h-5 w-5 text-teal-500" />
              ) : (
                <Circle className="h-5 w-5" />
              )}
            </button>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className={cn(
                  'text-sm font-medium',
                  task.completed ? 'line-through text-slate-400' : 'text-slate-900'
                )}>
                  {task.title}
                </span>
                <span className={cn('badge text-xs', PRIORITY_COLORS[task.priority])}>
                  {PRIORITY_LABELS[task.priority]}
                </span>
              </div>

              {task.description && (
                <p className="text-xs text-slate-500 mt-0.5 truncate">{task.description}</p>
              )}

              <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                {/* Type */}
                <span className="flex items-center gap-1 text-xs text-slate-400">
                  <Icon className="h-3 w-3" />
                  {TASK_TYPE_LABELS[task.type]}
                </span>

                {/* Due date */}
                {task.dueDate && (
                  <span className={cn(
                    'flex items-center gap-1 text-xs',
                    overdue && !task.completed ? 'text-red-500 font-medium' : 'text-slate-400'
                  )}>
                    <Clock className="h-3 w-3" />
                    {formatDate(task.dueDate)}
                    {overdue && !task.completed && ' — overdue'}
                  </span>
                )}

                {/* Linked contact */}
                {task.contact && (
                  <span className="flex items-center gap-1 text-xs text-slate-400">
                    <Users className="h-3 w-3" />
                    {getFullName(task.contact)}
                  </span>
                )}

                {/* Linked deal */}
                {task.deal && (
                  <span className="flex items-center gap-1 text-xs text-slate-400">
                    <TrendingUp className="h-3 w-3" />
                    {task.deal.title}
                  </span>
                )}
              </div>
            </div>

            {/* Assignee */}
            {task.assignee && (
              <div className="h-6 w-6 rounded-full bg-slate-200 text-slate-600 text-xs font-medium
                flex items-center justify-center shrink-0"
                title={task.assignee.name ?? ''}
              >
                {(task.assignee.name ?? '?').charAt(0).toUpperCase()}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
