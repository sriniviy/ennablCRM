import { formatRelativeTime, getInitials } from '@/lib/utils'
import {
  MessageSquare, Phone, Mail, Calendar, TrendingUp,
  CheckSquare, UserPlus, Star, ArrowRight,
} from 'lucide-react'
import type { ActivityWithRelations } from '@/types'

const ACTIVITY_ICONS: Record<string, React.ElementType> = {
  NOTE:             MessageSquare,
  CALL:             Phone,
  EMAIL_SENT:       Mail,
  EMAIL_OPENED:     Mail,
  EMAIL_CLICKED:    Mail,
  DEAL_CREATED:     TrendingUp,
  DEAL_MOVED:       ArrowRight,
  DEAL_WON:         Star,
  DEAL_LOST:        Star,
  TASK_CREATED:     CheckSquare,
  TASK_COMPLETED:   CheckSquare,
  CONTACT_CREATED:  UserPlus,
  MEETING:          Calendar,
}

const ACTIVITY_COLORS: Record<string, string> = {
  NOTE:             'bg-slate-100 text-slate-600',
  CALL:             'bg-green-100 text-green-600',
  EMAIL_SENT:       'bg-blue-100 text-blue-600',
  EMAIL_OPENED:     'bg-teal-100 text-teal-600',
  EMAIL_CLICKED:    'bg-teal-100 text-teal-700',
  DEAL_CREATED:     'bg-violet-100 text-violet-600',
  DEAL_MOVED:       'bg-indigo-100 text-indigo-600',
  DEAL_WON:         'bg-amber-100 text-amber-600',
  DEAL_LOST:        'bg-red-100 text-red-500',
  TASK_CREATED:     'bg-slate-100 text-slate-600',
  TASK_COMPLETED:   'bg-teal-100 text-teal-600',
  CONTACT_CREATED:  'bg-teal-100 text-teal-600',
  MEETING:          'bg-purple-100 text-purple-600',
}

interface Props {
  activities: ActivityWithRelations[]
  showAddNote?: boolean
}

export default function ActivityTimeline({ activities, showAddNote = true }: Props) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-slate-900">Activity</h2>
        {showAddNote && (
          <button className="btn-secondary text-xs">Log note</button>
        )}
      </div>

      {activities.length === 0 ? (
        <div className="py-12 text-center text-sm text-slate-400 card">
          No activity recorded yet.
        </div>
      ) : (
        <ol className="relative space-y-0">
          {activities.map((a, idx) => {
            const Icon = ACTIVITY_ICONS[a.type] ?? MessageSquare
            const colors = ACTIVITY_COLORS[a.type] ?? 'bg-slate-100 text-slate-600'
            const isLast = idx === activities.length - 1

            return (
              <li key={a.id} className="flex gap-4 pb-6 relative">
                {/* Vertical line */}
                {!isLast && (
                  <div className="absolute left-4 top-8 bottom-0 w-px bg-slate-100" />
                )}

                {/* Icon circle */}
                <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${colors}`}>
                  <Icon className="h-3.5 w-3.5" />
                </div>

                {/* Content */}
                <div className="flex-1 pt-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm font-medium text-slate-800">{a.title}</p>
                    <span className="text-xs text-slate-400 shrink-0">
                      {formatRelativeTime(a.createdAt)}
                    </span>
                  </div>
                  {a.description && (
                    <p className="text-sm text-slate-500 mt-0.5">{a.description}</p>
                  )}
                  {a.user && (
                    <p className="text-xs text-slate-400 mt-1">
                      by {a.user.name}
                    </p>
                  )}
                </div>
              </li>
            )
          })}
        </ol>
      )}
    </div>
  )
}
