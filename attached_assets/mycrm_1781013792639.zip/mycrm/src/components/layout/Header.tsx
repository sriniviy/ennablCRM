import { Search } from 'lucide-react'

interface HeaderProps {
  title: string
  subtitle?: string
  actions?: React.ReactNode
  onSearch?: (q: string) => void
  searchPlaceholder?: string
}

export default function Header({
  title,
  subtitle,
  actions,
  onSearch,
  searchPlaceholder = 'Search…',
}: HeaderProps) {
  return (
    <div className="flex items-center justify-between py-5 px-6 border-b border-slate-200 bg-white">
      <div>
        <h1 className="page-heading">{title}</h1>
        {subtitle && <p className="page-sub">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-3">
        {onSearch && (
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
            <input
              type="search"
              placeholder={searchPlaceholder}
              onChange={(e) => onSearch(e.target.value)}
              className="input pl-8 h-8 w-56 text-xs"
            />
          </div>
        )}
        {actions}
      </div>
    </div>
  )
}
