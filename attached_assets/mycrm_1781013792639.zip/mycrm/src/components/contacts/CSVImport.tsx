'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Modal from '@/components/shared/Modal'
import { useToast } from '@/components/shared/Toast'
import { Upload, FileText, AlertCircle, CheckCircle2 } from 'lucide-react'

interface Props {
  open: boolean
  onClose: () => void
  companies?: { id: string; name: string }[]
}

type Row = Record<string, string>

const CRM_FIELDS = [
  { key: 'firstName',  label: 'First name', required: true  },
  { key: 'lastName',   label: 'Last name',  required: true  },
  { key: 'email',      label: 'Email',      required: false },
  { key: 'phone',      label: 'Phone',      required: false },
  { key: 'title',      label: 'Job title',  required: false },
  { key: 'tags',       label: 'Tags',       required: false },
  { key: 'notes',      label: 'Notes',      required: false },
]

// ─── Simple CSV parser ────────────────────────────────────────────────────────
function parseCSV(text: string): { headers: string[]; rows: Row[] } {
  const lines = text.trim().split(/\r?\n/)
  if (lines.length < 2) return { headers: [], rows: [] }

  function parseLine(line: string): string[] {
    const result: string[] = []
    let cur = ''
    let inQuote = false
    for (let i = 0; i < line.length; i++) {
      const ch = line[i]
      if (ch === '"') {
        if (inQuote && line[i + 1] === '"') { cur += '"'; i++ }
        else inQuote = !inQuote
      } else if (ch === ',' && !inQuote) {
        result.push(cur.trim()); cur = ''
      } else {
        cur += ch
      }
    }
    result.push(cur.trim())
    return result
  }

  const headers = parseLine(lines[0])
  const rows = lines.slice(1).map((line) => {
    const vals = parseLine(line)
    return Object.fromEntries(headers.map((h, i) => [h, vals[i] ?? '']))
  })

  return { headers, rows }
}

// ─── Auto-detect column mapping ───────────────────────────────────────────────
function autoMap(headers: string[]): Record<string, string> {
  const map: Record<string, string> = {}
  const aliases: Record<string, string[]> = {
    firstName: ['first name', 'firstname', 'first', 'given name'],
    lastName:  ['last name', 'lastname', 'last', 'surname', 'family name'],
    email:     ['email', 'email address', 'e-mail'],
    phone:     ['phone', 'phone number', 'mobile', 'cell'],
    title:     ['title', 'job title', 'position', 'role'],
    tags:      ['tags', 'labels', 'categories'],
    notes:     ['notes', 'note', 'comments', 'description'],
  }

  for (const [field, aliasList] of Object.entries(aliases)) {
    const match = headers.find((h) =>
      aliasList.includes(h.toLowerCase().trim())
    )
    if (match) map[field] = match
  }
  return map
}

type Step = 'upload' | 'map' | 'preview' | 'done'

export default function CSVImport({ open, onClose, companies = [] }: Props) {
  const router    = useRouter()
  const { toast } = useToast()
  const fileRef   = useRef<HTMLInputElement>(null)

  const [step,     setStep]     = useState<Step>('upload')
  const [headers,  setHeaders]  = useState<string[]>([])
  const [rows,     setRows]     = useState<Row[]>([])
  const [mapping,  setMapping]  = useState<Record<string, string>>({})
  const [loading,  setLoading]  = useState(false)
  const [result,   setResult]   = useState<{ imported: number; skipped: number } | null>(null)
  const [fileName, setFileName] = useState('')

  function handleFile(file: File) {
    if (!file) return
    setFileName(file.name)
    const reader = new FileReader()
    reader.onload = (e) => {
      const { headers, rows } = parseCSV(e.target?.result as string)
      setHeaders(headers)
      setRows(rows)
      setMapping(autoMap(headers))
      setStep('map')
    }
    reader.readAsText(file)
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault()
    const file = e.dataTransfer.files[0]
    if (file?.name.endsWith('.csv')) handleFile(file)
  }

  // Build the contacts array based on mapping
  function getMappedRows() {
    return rows.map((row) => {
      const contact: Record<string, any> = {}
      for (const [field, col] of Object.entries(mapping)) {
        if (col) contact[field] = row[col] ?? ''
      }
      // Tags: split on semicolon or comma
      if (contact.tags) {
        contact.tags = String(contact.tags).split(/[,;]/).map((t: string) => t.trim()).filter(Boolean)
      }
      return contact
    }).filter((c) => c.firstName && c.lastName)
  }

  async function handleImport() {
    setLoading(true)
    try {
      const contacts = getMappedRows()
      const res = await fetch('/api/contacts/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contacts }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error ?? 'Import failed')
      setResult({ imported: data.imported, skipped: data.skipped })
      setStep('done')
      toast(`Imported ${data.imported} contacts`)
      router.refresh()
    } catch (err: any) {
      toast(err.message ?? 'Import failed', 'error')
    } finally {
      setLoading(false)
    }
  }

  function reset() {
    setStep('upload')
    setHeaders([])
    setRows([])
    setMapping({})
    setResult(null)
    setFileName('')
    onClose()
  }

  const valid     = getMappedRows()
  const canImport = valid.length > 0

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Import contacts from CSV"
      description="Map your CSV columns to contact fields. First name and last name are required."
      size="lg"
    >
      {/* Step: upload */}
      {step === 'upload' && (
        <div
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          className="border-2 border-dashed border-slate-200 rounded-xl p-10 text-center hover:border-teal-300 transition-colors cursor-pointer"
          onClick={() => fileRef.current?.click()}
        >
          <Upload className="h-8 w-8 text-slate-300 mx-auto mb-3" />
          <p className="text-sm font-medium text-slate-700">Drop a CSV file here, or click to browse</p>
          <p className="text-xs text-slate-400 mt-1">Headers in first row. Max 1,000 rows.</p>
          <input
            ref={fileRef}
            type="file"
            accept=".csv,text/csv"
            className="hidden"
            onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f) }}
          />
        </div>
      )}

      {/* Step: map columns */}
      {step === 'map' && (
        <div className="space-y-5">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <FileText className="h-4 w-4 text-teal-600" />
            <span className="font-medium">{fileName}</span>
            <span className="text-slate-400">· {rows.length} rows</span>
          </div>

          {/* Mapping grid */}
          <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
            <div className="grid grid-cols-2 px-4 py-2 bg-slate-50">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wide">CRM field</span>
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wide">CSV column</span>
            </div>
            {CRM_FIELDS.map(({ key, label, required }) => (
              <div key={key} className="grid grid-cols-2 items-center px-4 py-2.5 gap-4">
                <span className="text-sm text-slate-700">
                  {label}
                  {required && <span className="text-red-500 ml-0.5">*</span>}
                </span>
                <select
                  className="input text-sm"
                  value={mapping[key] ?? ''}
                  onChange={(e) => setMapping((m) => ({ ...m, [key]: e.target.value }))}
                >
                  <option value="">— Skip —</option>
                  {headers.map((h) => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>

          {/* Row count */}
          <div className={`flex items-center gap-2 text-sm rounded-lg px-3 py-2 ${canImport ? 'bg-teal-50 text-teal-700' : 'bg-amber-50 text-amber-700'}`}>
            {canImport
              ? <CheckCircle2 className="h-4 w-4 shrink-0" />
              : <AlertCircle className="h-4 w-4 shrink-0" />}
            {canImport
              ? `${valid.length} contacts ready to import`
              : 'Map at least First name and Last name to proceed'}
          </div>

          <div className="flex justify-end gap-2">
            <button className="btn-secondary" onClick={() => setStep('upload')}>Back</button>
            <button
              className="btn-secondary"
              disabled={!canImport}
              onClick={() => setStep('preview')}
            >
              Preview
            </button>
            <button className="btn-primary" disabled={!canImport || loading} onClick={handleImport}>
              {loading ? 'Importing…' : `Import ${valid.length} contacts`}
            </button>
          </div>
        </div>
      )}

      {/* Step: preview */}
      {step === 'preview' && (
        <div className="space-y-4">
          <p className="text-sm text-slate-600">First 5 rows of what will be imported:</p>
          <div className="overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  {CRM_FIELDS.filter((f) => mapping[f.key]).map((f) => (
                    <th key={f.key} className="text-left px-3 py-2 font-medium text-slate-600">
                      {f.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {valid.slice(0, 5).map((row, i) => (
                  <tr key={i}>
                    {CRM_FIELDS.filter((f) => mapping[f.key]).map((f) => (
                      <td key={f.key} className="px-3 py-2 text-slate-700 max-w-[140px] truncate">
                        {Array.isArray(row[f.key]) ? (row[f.key] as string[]).join(', ') : row[f.key]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {valid.length > 5 && (
            <p className="text-xs text-slate-400 text-center">
              … and {valid.length - 5} more rows
            </p>
          )}
          <div className="flex justify-end gap-2">
            <button className="btn-secondary" onClick={() => setStep('map')}>Back</button>
            <button className="btn-primary" disabled={loading} onClick={handleImport}>
              {loading ? 'Importing…' : `Confirm — import ${valid.length}`}
            </button>
          </div>
        </div>
      )}

      {/* Step: done */}
      {step === 'done' && result && (
        <div className="text-center py-8 space-y-3">
          <CheckCircle2 className="h-10 w-10 text-teal-500 mx-auto" />
          <h3 className="font-semibold text-slate-900">Import complete</h3>
          <p className="text-sm text-slate-600">
            {result.imported} contacts added
            {result.skipped > 0 && `, ${result.skipped} skipped (duplicate emails)`}
          </p>
          <button className="btn-primary mt-2" onClick={reset}>Done</button>
        </div>
      )}
    </Modal>
  )
}
