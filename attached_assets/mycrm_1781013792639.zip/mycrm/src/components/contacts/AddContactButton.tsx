'use client'

import { useState } from 'react'
import { Plus, Upload } from 'lucide-react'
import ContactForm from './ContactForm'
import CSVImport from './CSVImport'

interface Props {
  companies: { id: string; name: string }[]
}

export default function AddContactButton({ companies }: Props) {
  const [formOpen,   setFormOpen]   = useState(false)
  const [importOpen, setImportOpen] = useState(false)

  return (
    <>
      <div className="flex items-center gap-2">
        <button
          onClick={() => setImportOpen(true)}
          className="btn-secondary"
        >
          <Upload className="h-4 w-4" />
          Import CSV
        </button>
        <button
          onClick={() => setFormOpen(true)}
          className="btn-primary"
        >
          <Plus className="h-4 w-4" />
          Add contact
        </button>
      </div>

      <ContactForm
        open={formOpen}
        onClose={() => setFormOpen(false)}
        companies={companies}
      />

      <CSVImport
        open={importOpen}
        onClose={() => setImportOpen(false)}
        companies={companies}
      />
    </>
  )
}
