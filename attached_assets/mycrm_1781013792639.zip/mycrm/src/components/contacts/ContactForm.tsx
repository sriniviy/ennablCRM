'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Modal from '@/components/shared/Modal'
import { Field, Input, Select, TextArea } from '@/components/shared/FormField'
import { useToast } from '@/components/shared/Toast'
import { CONTACT_STATUS_LABELS } from '@/lib/utils'
import type { ContactFormData } from '@/types'

interface Company {
  id: string
  name: string
}

interface Props {
  open: boolean
  onClose: () => void
  companies?: Company[]
  initialData?: Partial<ContactFormData> & { id?: string }
  onSuccess?: (contact: any) => void
}

const DEFAULT: ContactFormData = {
  firstName: '',
  lastName:  '',
  email:     '',
  phone:     '',
  title:     '',
  status:    'LEAD',
  companyId: '',
  tags:      [],
  notes:     '',
  linkedIn:  '',
}

export default function ContactForm({ open, onClose, companies = [], initialData, onSuccess }: Props) {
  const router  = useRouter()
  const { toast } = useToast()
  const isEdit  = !!initialData?.id

  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')
  const [form,    setForm]    = useState<ContactFormData & { tagsRaw: string }>({
    ...DEFAULT,
    ...initialData,
    tagsRaw: initialData?.tags?.join(', ') ?? '',
  })

  function set<K extends keyof typeof form>(key: K, value: typeof form[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const payload = {
      firstName: form.firstName.trim(),
      lastName:  form.lastName.trim(),
      email:     form.email?.trim()     || undefined,
      phone:     form.phone?.trim()     || undefined,
      title:     form.title?.trim()     || undefined,
      status:    form.status,
      companyId: form.companyId         || undefined,
      linkedIn:  form.linkedIn?.trim()  || undefined,
      notes:     form.notes?.trim()     || undefined,
      tags:      form.tagsRaw.split(',').map((t) => t.trim()).filter(Boolean),
    }

    try {
      const url    = isEdit ? `/api/contacts/${initialData!.id}` : '/api/contacts'
      const method = isEdit ? 'PATCH' : 'POST'
      const res    = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()

      if (!res.ok) {
        setError(data.error ?? 'Something went wrong')
        return
      }

      toast(isEdit ? 'Contact updated' : 'Contact added')
      onSuccess?.(data.data)
      onClose()
      router.refresh()
    } catch {
      setError('Network error — please try again')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={isEdit ? 'Edit contact' : 'Add contact'}
      size="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="rounded-lg bg-red-50 text-red-700 text-sm px-3 py-2 border border-red-200">
            {error}
          </div>
        )}

        {/* Name row */}
        <div className="grid grid-cols-2 gap-3">
          <Field label="First name" required>
            <Input
              value={form.firstName}
              onChange={(e) => set('firstName', e.target.value)}
              placeholder="Jane"
              required
              autoFocus
            />
          </Field>
          <Field label="Last name" required>
            <Input
              value={form.lastName}
              onChange={(e) => set('lastName', e.target.value)}
              placeholder="Smith"
              required
            />
          </Field>
        </div>

        {/* Email + Phone */}
        <div className="grid grid-cols-2 gap-3">
          <Field label="Email">
            <Input
              type="email"
              value={form.email}
              onChange={(e) => set('email', e.target.value)}
              placeholder="jane@example.com"
            />
          </Field>
          <Field label="Phone">
            <Input
              value={form.phone}
              onChange={(e) => set('phone', e.target.value)}
              placeholder="+1 555 000 0000"
            />
          </Field>
        </div>

        {/* Title + Status */}
        <div className="grid grid-cols-2 gap-3">
          <Field label="Job title">
            <Input
              value={form.title}
              onChange={(e) => set('title', e.target.value)}
              placeholder="VP of Engineering"
            />
          </Field>
          <Field label="Status">
            <Select
              value={form.status}
              onChange={(e) => set('status', e.target.value as any)}
            >
              {Object.entries(CONTACT_STATUS_LABELS).map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))}
            </Select>
          </Field>
        </div>

        {/* Company */}
        {companies.length > 0 && (
          <Field label="Company">
            <Select
              value={form.companyId ?? ''}
              onChange={(e) => set('companyId', e.target.value)}
            >
              <option value="">— None —</option>
              {companies.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </Select>
          </Field>
        )}

        {/* Tags */}
        <Field label="Tags" hint="comma-separated">
          <Input
            value={form.tagsRaw}
            onChange={(e) => set('tagsRaw', e.target.value)}
            placeholder="enterprise, warm, q3"
          />
        </Field>

        {/* LinkedIn */}
        <Field label="LinkedIn URL">
          <Input
            value={form.linkedIn}
            onChange={(e) => set('linkedIn', e.target.value)}
            placeholder="https://linkedin.com/in/..."
          />
        </Field>

        {/* Notes */}
        <Field label="Notes">
          <TextArea
            rows={2}
            value={form.notes}
            onChange={(e) => set('notes', e.target.value)}
            placeholder="Initial notes about this contact…"
          />
        </Field>

        {/* Actions */}
        <div className="flex justify-end gap-2 pt-1">
          <button type="button" onClick={onClose} className="btn-secondary">
            Cancel
          </button>
          <button type="submit" disabled={loading} className="btn-primary">
            {loading ? 'Saving…' : isEdit ? 'Save changes' : 'Add contact'}
          </button>
        </div>
      </form>
    </Modal>
  )
}
