'use client'

import Link from 'next/link'
import { formatRelativeTime, getFullName, getInitials, CONTACT_STATUS_LABELS, CONTACT_STATUS_COLORS } from '@/lib/utils'
import { cn } from '@/lib/utils'
import type { ContactWithRelations } from '@/types'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useRouter } from 'next/navigation'

interface Props {
  contacts: ContactWithRelations[]
  total: number
  page: number
  pageSize: number
}

export default function ContactsTable({ contacts, total, page, pageSize }: Props) {
  const router = useRouter()
  const totalPages = Math.ceil(total / pageSize)

  if (contacts.length === 0) {
    return (
      <div className="card flex flex-col items-center justify-center py-24 text-center">
        <p className="text-slate-400 text-sm">No contacts yet.</p>
        <Link href="/contacts/new" className="btn-primary mt-4">
          Add your first contact
        </Link>
      </div>
    )
  }

  return (
    <div className="card overflow-hidden">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-slate-100">
            <th className="table-header px-4 py-3 text-left">Name</th>
            <th className="table-header px-4 py-3 text-left">Company</th>
            <th className="table-header px-4 py-3 text-left">Status</th>
            <th className="table-header px-4 py-3 text-left hidden md:table-cell">Email</th>
            <th className="table-header px-4 py-3 text-left hidden lg:table-cell">Deals</th>
            <th className="table-header px-4 py-3 text-left hidden xl:table-cell">Added</th>
          </tr>
        </thead>
        <tbody>
          {contacts.map((c) => (
            <tr
              key={c.id}
              className="table-row"
              onClick={() => router.push(`/contacts/${c.id}`)}
            >
              {/* Avatar + name */}
              <td className="px-4 py-3">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-teal-100 text-teal-700 text-xs font-semibold
                    flex items-center justify-center shrink-0">
                    {getInitials(getFullName(c))}
                  </div>
                  <div>
                    <div className="font-medium text-slate-900">{getFullName(c)}</div>
                    {c.title && <div className="text-xs text-slate-400">{c.title}</div>}
                  </div>
                </div>
              </td>

              {/* Company */}
              <td className="px-4 py-3 text-slate-600">
                {c.company ? (
                  <span
                    className="hover:underline hover:text-teal-700"
                    onClick={(e) => { e.stopPropagation(); router.push(`/companies/${c.company!.id}`) }}
                  >
                    {c.company.name}
                  </span>
                ) : (
                  <span className="text-slate-300">—</span>
                )}
              </td>

              {/* Status badge */}
              <td className="px-4 py-3">
                <span className={cn('badge', CONTACT_STATUS_COLORS[c.status])}>
                  {CONTACT_STATUS_LABELS[c.status]}
                </span>
              </td>

              {/* Email */}
              <td className="px-4 py-3 text-slate-500 hidden md:table-cell">
                {c.email ?? <span className="text-slate-300">—</span>}
              </td>

              {/* Deal count */}
              <td className="px-4 py-3 text-slate-500 hidden lg:table-cell">
                {c._count?.deals ?? 0}
              </td>

              {/* Added */}
              <td className="px-4 py-3 text-slate-400 text-xs hidden xl:table-cell">
                {formatRelativeTime(c.createdAt)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between border-t border-slate-100 px-4 py-3">
          <span className="text-xs text-slate-400">
            Showing {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, total)} of {total}
          </span>
          <div className="flex gap-1">
            <Link
              href={`?page=${page - 1}`}
              className={cn('btn-ghost p-1.5', page <= 1 && 'pointer-events-none opacity-40')}
            >
              <ChevronLeft className="h-4 w-4" />
            </Link>
            <Link
              href={`?page=${page + 1}`}
              className={cn('btn-ghost p-1.5', page >= totalPages && 'pointer-events-none opacity-40')}
            >
              <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      )}
    </div>
  )
}
