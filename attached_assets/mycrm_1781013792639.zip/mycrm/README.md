# MyCRM — Lightweight HubSpot Replacement

A full-featured CRM for small teams built with Next.js 14, PostgreSQL, Prisma, Clerk, and Resend.

---

## Features

| Module | What's included |
|---|---|
| **Contacts** | Search, filter by status, tag contacts, company associations, contact detail with timeline |
| **CSV Import** | Drag-and-drop CSV upload, auto column mapping, row preview, duplicate-email skipping |
| **Companies** | Company profiles, industry/size, linked contacts & deals, open pipeline value |
| **Pipeline** | Kanban board with drag-and-drop, deal value, probability slider, close date |
| **Tasks** | Due dates, priority, type (call/email/meeting), assignees, overdue/open/completed filter |
| **Email Campaigns** | Block-based email builder, live preview, HTML export, open & click tracking |
| **Activity log** | Every action auto-logged; manual note/call/meeting logging via API |
| **Dashboard** | Pipeline value, won-this-month, overdue tasks, recent activity feed |
| **Auth sync** | Clerk webhook auto-creates DB user record on sign-up |

---

## Tech stack

| Layer | Technology |
|---|---|
| Framework | Next.js 14 (App Router) |
| Language | TypeScript |
| Database | PostgreSQL |
| ORM | Prisma 5 |
| Auth | Clerk |
| Email | Resend |
| UI | Tailwind CSS + Radix UI primitives |
| Drag-and-drop | @hello-pangea/dnd |
| Hosting | Vercel (recommended) or Replit |

---

## Quick start on Replit

### 1. Import the project
Upload this zip or paste the repo URL into Replit's "Import from GitHub" flow.

### 2. Create a PostgreSQL database
In the Replit sidebar → **Database** tab → create a new **PostgreSQL** database.  
Copy the `DATABASE_URL` connection string.

### 3. Set environment variables
In Replit → **Secrets** tab, add each variable from `.env.example`:

```
DATABASE_URL        → your Replit PostgreSQL URL
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY
CLERK_SECRET_KEY    → from clerk.com (create a free app)
RESEND_API_KEY      → from resend.com (free tier: 100 emails/day)
NEXT_PUBLIC_APP_URL → https://YOUR-REPL.YOUR-USERNAME.repl.co
```

### 4. Install dependencies
Open the Replit Shell and run:
```bash
npm install
```

### 5. Push the database schema
```bash
npm run db:push
```

### 6. Seed initial data (deal stages + demo contact)
```bash
npm run db:seed
```

### 7. Start the dev server
```bash
npm run dev
```

Visit your Replit URL — you'll be redirected to the Clerk sign-in page.

---

## Local development

```bash
# 1. Clone / unzip
cd mycrm

# 2. Copy env file and fill in your values
cp .env.example .env

# 3. Install
npm install

# 4. Push schema to your Postgres DB
npm run db:push

# 5. Seed deal stages
npm run db:seed

# 6. Run
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

---

## Project structure

```
src/
├── app/
│   ├── (auth)/             # Sign-in / sign-up pages (Clerk)
│   ├── (dashboard)/        # All CRM pages behind auth
│   │   ├── dashboard/      # Stats overview
│   │   ├── contacts/       # List + detail pages
│   │   ├── companies/      # Company list
│   │   ├── deals/          # Kanban pipeline
│   │   ├── tasks/          # Task list with filters
│   │   └── campaigns/      # Email campaign list
│   └── api/
│       ├── contacts/       # CRUD endpoints
│       ├── companies/      # CRUD endpoints
│       ├── deals/          # CRUD + stage moves
│       ├── tasks/          # CRUD + complete toggle
│       ├── campaigns/      # Create + send
│       └── track/
│           ├── open/[id]   # Tracking pixel (1×1 GIF)
│           └── click/[id]  # Link click redirect
├── components/
│   ├── layout/             # Sidebar, Header
│   ├── contacts/           # ContactsTable
│   ├── deals/              # KanbanBoard (drag-and-drop)
│   └── shared/             # ActivityTimeline, TaskList
├── lib/
│   ├── prisma.ts           # Prisma singleton
│   ├── utils.ts            # Formatters, CN helper, status maps
│   └── resend.ts           # Email sending + tracking injection
└── types/
    └── index.ts            # All TypeScript interfaces
```

---

## Adding a Contact form

The contacts list page links to `/contacts/new`. You'll need to create:

```
src/app/(dashboard)/contacts/new/page.tsx
```

Use `fetch('/api/contacts', { method: 'POST', body: JSON.stringify({...}) })` to save.

---

## Email campaigns

### Setup
1. Go to [resend.com](https://resend.com) and add your sending domain  
2. Add `RESEND_API_KEY` to your secrets  
3. Set `NEXT_PUBLIC_APP_URL` to your deployed URL (needed for tracking pixels)

### How it works
1. Create a campaign with HTML content (`POST /api/campaigns`)
2. Send it (`PATCH /api/campaigns` with `{ action: 'send' }`)
3. Resend delivers each email with an injected tracking pixel and link wrappers
4. Opens → `GET /api/track/open/[campaignContactId]` (returns 1×1 GIF)
5. Clicks → `GET /api/track/click/[campaignContactId]?url=...` (redirects)

> **Production note**: For large lists, replace the `Promise.allSettled` send loop with a job queue (e.g. [Trigger.dev](https://trigger.dev) or [BullMQ](https://bullmq.io)).

---

## Deploying to Vercel

```bash
npm install -g vercel
vercel
```

Add all environment variables in the Vercel dashboard under **Settings → Environment Variables**.  
Run `npm run db:push` once after setting `DATABASE_URL` to apply the schema.

---

## Roadmap (what to build next)

- [x] Contact & deal creation forms (modal dialogs)  
- [x] CSV import for contacts  
- [x] Email template block-based builder  
- [x] Company detail page  
- [x] Clerk webhook → auto-sync users to DB  
- [ ] Company creation form  
- [ ] Note / call log form on contact/deal detail pages  
- [ ] Deal reports & won/lost analytics chart  
- [ ] Zapier / webhook integrations  
- [ ] Multi-team support  
- [ ] Mobile-responsive sidebar (hamburger menu)  
- [ ] Scheduled campaign sending (with a job queue)

---

## License

MIT — use freely, build on it.
