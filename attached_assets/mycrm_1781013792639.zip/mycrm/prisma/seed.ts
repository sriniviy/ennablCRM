import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding database...')

  // Create default deal stages
  const stages = [
    { name: 'Lead',       order: 0, color: '#94a3b8' },
    { name: 'Qualified',  order: 1, color: '#14b8a6' },
    { name: 'Proposal',   order: 2, color: '#6366f1' },
    { name: 'Negotiation',order: 3, color: '#f59e0b' },
    { name: 'Won',        order: 4, color: '#22c55e' },
    { name: 'Lost',       order: 5, color: '#ef4444' },
  ]

  for (const stage of stages) {
    await prisma.dealStage.upsert({
      where: { id: `stage-${stage.name.toLowerCase()}` },
      create: { id: `stage-${stage.name.toLowerCase()}`, ...stage },
      update: stage,
    })
  }

  console.log('✅ Deal stages created')

  // Demo company
  const acme = await prisma.company.upsert({
    where: { domain: 'acme.com' },
    create: {
      name: 'Acme Corp',
      domain: 'acme.com',
      industry: 'Technology',
      size: '51-200',
      website: 'https://acme.com',
    },
    update: {},
  })

  // Demo contact
  await prisma.contact.upsert({
    where: { email: 'jane@acme.com' },
    create: {
      firstName: 'Jane',
      lastName: 'Smith',
      email: 'jane@acme.com',
      title: 'VP of Engineering',
      status: 'CUSTOMER',
      companyId: acme.id,
      tags: ['enterprise', 'warm'],
    },
    update: {},
  })

  console.log('✅ Demo data created')
  console.log('Seeding complete!')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
